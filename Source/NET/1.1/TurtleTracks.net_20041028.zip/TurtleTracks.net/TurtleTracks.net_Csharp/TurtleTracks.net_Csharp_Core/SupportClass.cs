using System;
public interface IThreadRunnable
{
	void Run();
}

public class SupportClass
{
	public class ThreadClass:IThreadRunnable
	{
		private System.Threading.Thread threadField;

		public ThreadClass()
		{
			threadField = new System.Threading.Thread(new System.Threading.ThreadStart(Run));
		}

		public ThreadClass(System.Threading.ThreadStart p1)
		{
			threadField = new System.Threading.Thread(p1);
		}

		public virtual void Run()
		{
		}

		public virtual void Start()
		{
			threadField.Start();
		}
	      
		/// <summary>
		/// Interrupts a thread that is in the WaitSleepJoin thread state
		/// </summary>
		public virtual void Interrupt() //Birb-JLCA: copied from VS.net2005beta1 JLCA conversion
		{
			threadField.Interrupt();
		}

		public System.Threading.Thread Instance
		{
			get
			{
				return threadField;
			}
			set
			{
				threadField	= value;
			}
		}

		public System.String Name
		{
			get
			{
				return threadField.Name;
			}
			set
			{
				if (threadField.Name == null)
					threadField.Name = value; 
			}
		}

		public System.Threading.ThreadPriority Priority
		{
			get
			{
				return threadField.Priority;
			}
			set
			{
				threadField.Priority = value;
			}
		}

		public bool IsAlive
		{
			get
			{
				return threadField.IsAlive;
			}
		}

		public bool IsBackground
		{
			get
			{
				return threadField.IsBackground;
			} 
			set
			{
				threadField.IsBackground = value;
			}
		}

		public void Join()
		{
			threadField.Join();
		}

		public void Join(long p1)
		{
			lock(this)
			{
				threadField.Join(new System.TimeSpan(p1 * 10000));
			}
		}

		public void Join(long p1, int p2)
		{
			lock(this)
			{
				threadField.Join(new System.TimeSpan(p1 * 10000 + p2 * 100));
			}
		}

		public void Resume()
		{
			threadField.Resume();
		}

		public void Abort()
		{
			threadField.Abort();
		}

		public void Abort(System.Object stateInfo)
		{
			lock(this)
			{
				threadField.Abort(stateInfo);
			}
		}

		public void Suspend()
		{
			threadField.Suspend();
		}

		public override System.String ToString()
		{
			return "Thread[" + Name + "," + Priority.ToString() + "," + "" + "]";
		}

		public static ThreadClass Current()
		{
			ThreadClass CurrentThread = new ThreadClass();
			CurrentThread.Instance = System.Threading.Thread.CurrentThread;
			return CurrentThread;
		}
	}

	/*******************************/
	public static void WriteStackTrace(System.Exception throwable, System.IO.TextWriter stream)
	{
		stream.Write(throwable.StackTrace);
		stream.Flush();
	}

	/*******************************/
	public class RandomAccessFileSupport
	{
		public static System.IO.FileStream CreateRandomAccessFile(string fileName, string mode) 
		{
			System.IO.FileStream newFile = null;

			if (mode.CompareTo("rw") == 0)
				newFile =  new System.IO.FileStream(fileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite); 
			else if (mode.CompareTo("r") == 0 )
				newFile =  new System.IO.FileStream(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read); 
			else
				throw new System.ArgumentException();

			return newFile;
		}

		public static System.IO.FileStream CreateRandomAccessFile(System.IO.FileInfo fileName, string mode)
		{
			return CreateRandomAccessFile(fileName.FullName, mode);
		}

		public static void WriteBytes(string data,System.IO.FileStream fileStream)
		{
			int index = 0;
			int length = data.Length;

			while(index < length)
				fileStream.WriteByte((byte)data[index++]);	
		}

		public static void WriteChars(string data,System.IO.FileStream fileStream)
		{
			WriteBytes(data, fileStream);	
		}

		public static void WriteRandomFile(sbyte[] sByteArray,System.IO.FileStream fileStream)
		{
			byte[] byteArray = ToByteArray(sByteArray);
			fileStream.Write(byteArray, 0, byteArray.Length);
		}
	}

	/*******************************/
	/// <summary>
	/// Converts an array of sbytes to an array of bytes
	/// </summary>
	/// <param name="sbyteArray">The array of sbytes to be converted</param>
	/// <returns>The new array of bytes</returns>
	public static byte[] ToByteArray(sbyte[] sbyteArray)
	{
		byte[] byteArray = new byte[sbyteArray.Length];
		for(int index=0; index < sbyteArray.Length; index++)
			byteArray[index] = (byte) sbyteArray[index];
		return byteArray;
	}

	/// <summary>
	/// Converts a string to an array of bytes
	/// </summary>
	/// <param name="sourceString">The string to be converted</param>
	/// <returns>The new array of bytes</returns>
	public static byte[] ToByteArray(string sourceString)
	{
		byte[] byteArray = new byte[sourceString.Length];
		for (int index=0; index < sourceString.Length; index++)
			byteArray[index] = (byte) sourceString[index];
		return byteArray;
	}

	/*******************************/
	/// <summary>Reads a number of characters from the current source Stream and writes the data to the target array at the specified index.</summary>
	/// <param name="sourceStream">The source Stream to read from</param>
	/// <param name="target">Contains the array of characteres read from the source Stream.</param>
	/// <param name="start">The starting index of the target array.</param>
	/// <param name="count">The maximum number of characters to read from the source Stream.</param>
	/// <returns>The number of characters read. The number will be less than or equal to count depending on the data available in the source Stream.</returns>
	public static System.Int32 ReadInput(System.IO.Stream sourceStream, ref sbyte[] target, int start, int count)
	{
		byte[] receiver = new byte[target.Length];
		int bytesRead   = sourceStream.Read(receiver, start, count);
			
		for(int i = start; i < start + bytesRead; i++)
			target[i] = (sbyte)receiver[i];
			
		return bytesRead;
	}

	/// <summary>Reads a number of characters from the current source TextReader and writes the data to the target array at the specified index.</summary>
	/// <param name="sourceTextReader">The source TextReader to read from</param>
	/// <param name="target">Contains the array of characteres read from the source TextReader.</param>
	/// <param name="start">The starting index of the target array.</param>
	/// <param name="count">The maximum number of characters to read from the source TextReader.</param>
	/// <returns>The number of characters read. The number will be less than or equal to count depending on the data available in the source TextReader.</returns>
	public static System.Int32 ReadInput(System.IO.TextReader sourceTextReader, ref sbyte[] target, int start, int count)
	{
		char[] charArray = new char[target.Length];
		int bytesRead = sourceTextReader.Read(charArray, start, count);

		for(int index=start; index<start+bytesRead; index++)
			target[index] = (sbyte)charArray[index];

		return bytesRead;
	}

	/*******************************/
	/// <summary>
	/// Creates an instance of a received Type
	/// </summary>
	/// <param name="classType">The Type of the new class instance to return</param>
	/// <returns>An Object containing the new instance</returns>
	public static System.Object CreateNewInstance(System.Type classType)
	{
		System.Reflection.ConstructorInfo[] constructors = classType.GetConstructors();

		if (constructors.Length == 0)
			return null;

		System.Reflection.ParameterInfo[] firstConstructor = constructors[0].GetParameters();
		int countParams = firstConstructor.Length;

		System.Type[] constructor = new System.Type[countParams];
		for( int i = 0; i < countParams; i++)
			constructor[i] = firstConstructor[i].ParameterType;

		return classType.GetConstructor(constructor).Invoke(new System.Object[]{});
	}

	/*******************************/
	public static System.Object PutElement(System.Collections.Hashtable hashTable, System.Object key, System.Object newValue)
	{
		System.Object element = hashTable[key];
		hashTable[key] = newValue;
		return element;
	}

	/*******************************/
	/// <summary>
	/// Removes the element with the specified key from a Hashtable instance.
	/// </summary>
	/// <param name="hashtable">The Hashtable instance</param>
	/// <param name="key">The key of the element to remove</param>
	/// <returns>The element removed</returns>  
	public static System.Object HashtableRemove(System.Collections.Hashtable hashtable, System.Object key)
	{
		System.Object element = hashtable[key];
		hashtable.Remove(key);
		return element;
	}

	/*******************************/
	public class Tokenizer
	{
		private System.Collections.ArrayList elements;
		private string source;
		//The tokenizer uses the default delimiter set: the space character, the tab character, the newline character, and the carriage-return character
		private string delimiters = " \t\n\r";		

		public Tokenizer(string source)
		{			
			this.elements = new System.Collections.ArrayList();
			this.elements.AddRange(source.Split(this.delimiters.ToCharArray()));
			this.RemoveEmptyStrings();
			this.source = source;
		}

		public Tokenizer(string source, string delimiters)
		{
			this.elements = new System.Collections.ArrayList();
			this.delimiters = delimiters;
			this.elements.AddRange(source.Split(this.delimiters.ToCharArray()));
			this.RemoveEmptyStrings();
			this.source = source;
		}

		public int Count
		{
			get
			{
				return (this.elements.Count);
			}
		}

		public bool HasMoreTokens()
		{
			return (this.elements.Count > 0);			
		}

		public string NextToken()
		{			
			string result;
			if (source == "") throw new System.Exception();
			else
			{
				this.elements = new System.Collections.ArrayList();
				this.elements.AddRange(this.source.Split(delimiters.ToCharArray()));
				RemoveEmptyStrings();		
				result = (string) this.elements[0];
				this.elements.RemoveAt(0);				
				this.source = this.source.Remove(this.source.IndexOf(result),result.Length);
				this.source = this.source.TrimStart(this.delimiters.ToCharArray());
				return result;					
			}			
		}

		public string NextToken(string delimiters)
		{
			this.delimiters = delimiters;
			return NextToken();
		}

		private void RemoveEmptyStrings()
		{
			//VJ++ does not treat empty strings as tokens
			for (int index=0; index < this.elements.Count; index++)
				if ((string)this.elements[index]== "")
				{
					this.elements.RemoveAt(index);
					index--;
				}
		}
	}

}
