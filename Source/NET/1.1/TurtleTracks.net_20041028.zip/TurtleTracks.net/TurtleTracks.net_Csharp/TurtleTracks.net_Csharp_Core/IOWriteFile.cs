/*
===============================================================================

FILE:  IOWriteFile.java

PROJECT:

Turtle Tracks

CONTENTS:

Write file object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Stream that writes to a file
	/// </summary>
	
	public class IOWriteFile:IOStream
	{
		
		new private static LogoObject _kind;
		
		
		
		
		/// <summary> Constructor
		/// *
		/// </summary>
		/// <param name="f">file to open
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException unable to open file
		/// 
		/// </exception>
		public IOWriteFile(System.IO.FileInfo f)
		{
			try
			{
				//UPGRADE_ISSUE: Constructor 'java.io.BufferedWriter.BufferedWriter' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javaioBufferedWriterBufferedWriter_javaioWriter"'
				open(new LogoWord(f.FullName), new BufferedWriter(new System.IO.StreamWriter(f.FullName)));
			}
			catch (System.IO.IOException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				throw new LanguageException("Couldn't open file: \"" + f.FullName + "\" I/O: " + e.Message);
			}
			catch (System.Security.SecurityException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				throw new LanguageException("Couldn't open file: \"" + f.FullName + "\" Security: " + e.ToString());
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'kind'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get the kind of this object
		/// *
		/// </summary>
		/// <returns> the kind as a LogoObject
		/// 
		/// </returns>
		public override LogoObject kind()
		{
			lock (this)
			{
				return _kind;
			}
		}
		static IOWriteFile()
		{
			{
				_kind = new LogoWord("WRITEFILE");
			}
		}
	}
}