/*
===============================================================================

FILE:  IOBase.java

PROJECT:

Turtle Tracks

CONTENTS:

Interface to logo stream objects

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> IO interface. This is the base interface for all stream objects
	/// </summary>
	
	public interface IOBase
		{
			/// <summary> Is the stream open?
			/// *
			/// </summary>
			/// <returns> true iff can interact with stream
			/// 
			/// </returns>
			bool Open
			{
				get;
				
			}
			/// <summary> Get a line from the stream
			/// *
			/// </summary>
			/// <returns> the string
			/// *
			/// </returns>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
			/// 
			/// </exception>
			System.String Line
			{
				get;
				
			}
			/// <summary> Get a character from the stream
			/// *
			/// </summary>
			/// <returns> char the character
			/// *
			/// </returns>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
			/// 
			/// </exception>
			char Char
			{
				get;
				
			}
			/// <summary> Close the stream
			/// *
			/// </summary>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException can't close
			/// 
			/// </exception>
			void  close();
			/// <summary> Get the name of this object
			/// *
			/// </summary>
			/// <returns> the name as a LogoObject
			/// 
			/// </returns>
			LogoObject name();
			/// <summary> Get the kind of this object
			/// *
			/// </summary>
			/// <returns> the kind as a LogoObject
			/// 
			/// </returns>
			LogoObject kind();
			/// <summary> Has the stream encountered EOF?
			/// *
			/// </summary>
			/// <returns> true iff eof encountered
			/// *
			/// </returns>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException stream closed
			/// 
			/// </exception>
			bool eof();
			/// <summary> Get all available data from stream
			/// *
			/// </summary>
			/// <param name="buf">buffer to read into
			/// *
			/// </param>
			/// <returns> how much data was actually read
			/// *
			/// </returns>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
			/// 
			/// </exception>
			int getAvailable(char[] buf);
			/// <summary> Character available on stream?
			/// *
			/// </summary>
			/// <returns> true iff available
			/// *
			/// </returns>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
			/// 
			/// </exception>
			bool charAvail();
			/// <summary> Write a string to the stream
			/// *
			/// </summary>
			/// <param name="str">the string
			/// *
			/// </param>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
			/// 
			/// </exception>
			void  put(System.String str);
			/// <summary> Write a char to the stream
			/// *
			/// </summary>
			/// <param name="c">the char
			/// *
			/// </param>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
			/// 
			/// </exception>
			void  put(char c);
			/// <summary> Write a char array to the stream
			/// *
			/// </summary>
			/// <param name="buf">the buffer
			/// </param>
			/// <param name="num">number of characters
			/// *
			/// </param>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
			/// 
			/// </exception>
			void  put(char[] buf, int num);
			/// <summary> Write a string to the stream, terminated with a newline
			/// *
			/// </summary>
			/// <param name="str">the string
			/// *
			/// </param>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
			/// 
			/// </exception>
			void  putLine(System.String str);
			/// <summary> Flush the stream
			/// *
			/// </summary>
			/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
			/// 
			/// </exception>
			void  flush();
		}
}