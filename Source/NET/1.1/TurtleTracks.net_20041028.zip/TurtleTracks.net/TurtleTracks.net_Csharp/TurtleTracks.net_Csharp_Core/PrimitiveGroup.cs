/*
===============================================================================

FILE:  PrimitiveGroup.java

PROJECT:

Turtle Tracks

CONTENTS:

PrimitiveGroup abstract class

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> PrimitiveGroup abstract class. Primitive implementations must extend this
	/// class.
	/// </summary>
	
	public abstract class PrimitiveGroup
	{
		
		private System.Type _thisClass;
		private static System.Type[] _params;
		
		private System.Collections.Hashtable _primitiveTable;
		
		
		
		
		/// <summary> Constructor
		/// </summary>
		protected internal PrimitiveGroup()
		{
			_primitiveTable = new System.Collections.Hashtable();
			_thisClass = GetType();
		}
		
		
		/// <summary> Create a primitive definition spec given a primitive name
		/// *
		/// </summary>
		/// <param name="name">word
		/// *
		/// </param>
		/// <returns> the method, or null for not in this primitive group
		/// 
		/// </returns>
		public PrimitiveSpec getPrimitiveMethod(CaselessString name)
		{
			return (PrimitiveSpec) (_primitiveTable[name]);
		}
		
		
		/// <summary> Is this name a primitive in this group
		/// *
		/// </summary>
		/// <param name="name">the string to look for
		/// *
		/// </param>
		/// <returns> true if and only if this primitive is implemented in this PrimitiveGroup
		/// 
		/// </returns>
		public bool isPrimitive(CaselessString name)
		{
			return _primitiveTable[name] != null;
		}
		
		
		/// <summary> Set up one primitive in current primitive group. Should be called from setup().
		/// *
		/// </summary>
		/// <param name="primitiveName">the name of the primitive
		/// </param>
		/// <param name="methodName">the name of the method that implements the primitive.
		/// </param>
		/// <param name="numDefArgs">default number of arguments for this primitive
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.SetupException no such method
		/// 
		/// </exception>
		protected internal void  registerPrimitive(System.String primitiveName, System.String methodName, int numDefArgs)
		{
			try
			{
				try
				{
					//UPGRADE_TODO: Method 'java.lang.Class.getDeclaredMethod' was converted to 'System.Type.GetMethod' which has a different behavior. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1073"'
					//UPGRADE_WARNING: Method 'java.lang.Class.getDeclaredMethod' was converted to 'System.Type.GetMethod' which may throw an exception. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1101"'
					SupportClass.PutElement(_primitiveTable, new CaselessString(primitiveName), new PrimitiveSpec(this, _thisClass.GetMethod(methodName, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.DeclaredOnly, null, _params, null), numDefArgs));
				}
				catch (System.Security.SecurityException e)
				{
					SupportClass.PutElement(_primitiveTable, new CaselessString(primitiveName), new PrimitiveSpec(this, _thisClass.GetMethod(methodName, (System.Type[]) _params), numDefArgs));
				}
			}
			catch (System.Security.SecurityException e)
			{
				throw new SetupException("Security prohibits reflection", SetupException.securityError);
			}
			catch (System.MethodAccessException e)
			{
				throw new SetupException("No such method: " + methodName, SetupException.noSuchMethodErr);
			}
		}
		
		
		/// <summary> Alias one primitive to the setup in another primitive group
		/// *
		/// </summary>
		/// <param name="primitiveName">the name of the primitive
		/// </param>
		/// <param name="group">PrimitiveGroup to proxy.
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.SetupException no such primitive in proxy
		/// 
		/// </exception>
		protected internal void  registerPrimitive(System.String primitiveName, PrimitiveGroup group)
		{
			PrimitiveSpec spec = group.getPrimitiveMethod(new CaselessString(primitiveName));
			if (spec == null)
			{
				throw new SetupException("No such primitive: " + primitiveName + " in group " + group.GetType().FullName, SetupException.noSuchPrimitiveErr);
			}
			else
			{
				SupportClass.PutElement(_primitiveTable, new CaselessString(primitiveName), spec);
			}
		}
		
		
		/// <summary> Alias one primitive to another primitive in another primitive group
		/// *
		/// </summary>
		/// <param name="primitiveName">the name of the primitive
		/// </param>
		/// <param name="group">PrimitiveGroup to proxy.
		/// </param>
		/// <param name="otherName">primitive name in the proxy primitive group
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.SetupException no such primitive in proxy
		/// 
		/// </exception>
		protected internal void  registerPrimitive(System.String primitiveName, PrimitiveGroup group, System.String otherName)
		{
			PrimitiveSpec spec = group.getPrimitiveMethod(new CaselessString(otherName));
			if (spec == null)
			{
				throw new SetupException("No such primitive: " + otherName + " in group " + group.GetType().FullName, SetupException.noSuchPrimitiveErr);
			}
			else
			{
				SupportClass.PutElement(_primitiveTable, new CaselessString(primitiveName), spec);
			}
		}
		
		
		/// <summary> A primitive group must implement this method to register all its primitives.
		/// *
		/// </summary>
		/// <param name="mach">the machine in use.
		/// </param>
		/// <param name="console">useful for printing an initialization message.
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.SetupException Could not set up the primitive group for some reason
		/// 
		/// </exception>
		protected internal abstract void  setup(Machine mach, Console console);
		
		
		/// <summary> Called when VM is closing down. Override to perform any necessary cleanup.
		/// </summary>
		protected internal virtual void  exiting()
		{
		}
		
		
		/// <summary> Test the parameter list for correct number of arguments.
		/// *
		/// </summary>
		/// <param name="params">the parameter list
		/// </param>
		/// <param name="i">the expected number of parameters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parameter number mismatch
		/// 
		/// </exception>
		protected internal void  testNumParams(LogoObject[] params_Renamed, int i)
		{
			if (params_Renamed.Length > i)
			{
				throw new LanguageException("Too many arguments");
			}
			else if (params_Renamed.Length < i)
			{
				throw new LanguageException("Not enough arguments");
			}
		}
		
		
		/// <summary> Test the parameter list for correct number of arguments
		/// *
		/// </summary>
		/// <param name="params">the parameter list
		/// </param>
		/// <param name="i">the minimum expected number of parameters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parameter number mismatch
		/// 
		/// </exception>
		protected internal void  testMinParams(LogoObject[] params_Renamed, int i)
		{
			if (params_Renamed.Length < i)
			{
				throw new LanguageException("Not enough arguments");
			}
		}
		
		
		/// <summary> Test the parameter list for correct number of arguments
		/// *
		/// </summary>
		/// <param name="params">the parameter list
		/// </param>
		/// <param name="i">the maximum expected number of parameters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parameter number mismatch
		/// 
		/// </exception>
		protected internal void  testMaxParams(LogoObject[] params_Renamed, int i)
		{
			if (params_Renamed.Length > i)
			{
				throw new LanguageException("Too many arguments");
			}
		}
		
		
		/// <summary> Test the parameter list for correct number of arguments
		/// *
		/// </summary>
		/// <param name="params">the parameter list
		/// </param>
		/// <param name="min">the minimum expected number of parameters
		/// </param>
		/// <param name="max">the maximum expected number of parameters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parameter number mismatch
		/// 
		/// </exception>
		protected internal void  testNumParams(LogoObject[] params_Renamed, int min, int max)
		{
			if (params_Renamed.Length > max)
			{
				throw new LanguageException("Too many arguments");
			}
			else if (params_Renamed.Length < min)
			{
				throw new LanguageException("Not enough arguments");
			}
		}
		
		
		/// <summary> Apply given procedure to given values.
		/// *
		/// </summary>
		/// <param name="interp">the InterpEnviron
		/// </param>
		/// <param name="name">the name of the procedure or primitive
		/// </param>
		/// <param name="paramValues">the values of the arguments.
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.csharp.ThrowException exception thrown
		/// 
		/// </exception>
		protected internal static LogoObject applyProc(InterpEnviron interp, CaselessString name, LogoList paramValues)
		{
			ParseObject[] cmds = new ParseObject[1];
			int len = paramValues.length();
			LogoObject[] arr = new LogoObject[len];
			for (int i = 0; i < len; i++)
			{
				arr[i] = paramValues.pickInPlace(i);
			}
			
			Procedure proc = interp.mach().resolveProc(name);
			if (proc != null)
			{
				cmds[0] = new ParseProcedure(proc, arr);
			}
			else
			{
				PrimitiveSpec prim = interp.mach().findPrimitive(name);
				if (prim != null)
				{
					cmds[0] = new ParsePrimitive(prim, name.str, arr);
				}
				else
				{
					throw new LanguageException("I don't know how to " + name);
				}
			}
			return new ParseTree(0, cmds).execute(interp);
		}
		
		
		/// <summary> Apply given lambda to given values
		/// *
		/// </summary>
		/// <param name="interp">the InterpEnviron
		/// </param>
		/// <param name="lambda">the lambda list
		/// </param>
		/// <param name="paramValues">the values of the arguments.
		/// </param>
		/// <param name="strictParams">if true, an exception is thrown if fewer actual parameters
		/// are given than formal parameters. if false, then the unset formal
		/// parameters are simply not bound.
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.csharp.ThrowException exception thrown
		/// 
		/// </exception>
		protected internal static LogoObject applyAnonymous(InterpEnviron interp, LogoList lambda, LogoList paramValues, bool strictParams)
		{
			// Parse lambda list
			if (lambda.length() == 0 || !(lambda.pickInPlace(0) is LogoList))
			{
				throw new LanguageException("Lambda list expected");
			}
			LogoList paramNames = (LogoList) (lambda.pickInPlace(0));
			LogoList runnable;
			bool isMacro = false;
			if (lambda.pickInPlace(1) is LogoList)
			{
				if (lambda.length() > 2)
				{
					throw new LanguageException("Lambda list expected");
				}
				runnable = (LogoList) (lambda.pickInPlace(1));
			}
			else
			{
				isMacro = true;
				runnable = (LogoList) (lambda.butFirst());
			}
			
			// Bind parameters
			SymbolTable local = new SymbolTable();
			int nlen = paramNames.length();
			int vlen = paramValues.length();
			if ((strictParams && nlen != vlen) || (!strictParams && nlen > vlen))
			{
				throw new LanguageException("Wrong number of arguments");
			}
			for (int i = 0; i < nlen; i++)
			{
				if (!(paramNames.pickInPlace(i) is LogoWord))
				{
					throw new LanguageException("Bad symbol list in lambda expression");
				}
				local.makeForced(paramNames.pickInPlace(i).toCaselessString(), paramValues.pickInPlace(i));
			}
			
			// Invoke
			LogoObject ret = LogoVoid.obj;
			InterpEnviron interp2 = new InterpEnviron(interp);
			interp.thread().enterProcedure(local);
			LogoObject obj = LogoVoid.obj;
			try
			{
				obj = runnable.getRunnable(interp.mach()).execute(interp2);
			}
			catch (ThrowException e)
			{
				if (!isMacro && e.Tag.Equals("STOP"))
				{
					ret = e.Obj;
				}
				else
				{
					throw e;
				}
			}
			finally
			{
				interp.thread().exitProcedure();
			}
			if (isMacro)
			{
				ret = obj;
			}
			else if (obj != LogoVoid.obj)
			{
				throw new LanguageException("I don't know what to do with " + obj);
			}
			return ret;
		}
		static PrimitiveGroup()
		{
			{
				_params = new System.Type[2];
				_params[0] = (new InterpEnviron()).GetType();
				_params[1] = (new LogoObject[1]).GetType();
			}
		}
	}
}