/*
===============================================================================

FILE:  LogoWord.java

PROJECT:

Turtle Tracks

CONTENTS:

Word logo object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	
	
	/// <summary> Word object
	/// </summary>
	
	public class LogoWord:LogoObject
	{
		/// <summary> Get the type code
		/// *
		/// </summary>
		/// <returns> the type
		/// 
		/// </returns>
		virtual internal sbyte Type
		{
			get
			{
				return _type;
			}
			
		}
		
		private System.String _str;
		private System.String _unparsed;
		private sbyte _type;
		private double _val;
		
		private const System.String _true = "TRUE";
		private const System.String _false = "FALSE";
		
		internal const sbyte TYPE_WORD = 1;
		internal const sbyte TYPE_PUNCT = 2;
		internal const sbyte TYPE_INT = 3;
		internal const sbyte TYPE_FLOAT = 4;
		
		
		/// <summary> Construct an empty word
		/// </summary>
		public LogoWord()
		{
			_str = "";
			_unparsed = "";
			_type = TYPE_WORD;
			_val = 0;
		}
		
		
		/// <summary> Construct a word given complete info (used by clone)
		/// </summary>
		private LogoWord(System.String s, System.String u, sbyte t, double v)
		{
			_str = s;
			_unparsed = u;
			_type = t;
			_val = v;
		}
		
		
		/// <summary> Construct a word with a given string and unparsed string info
		/// *
		/// </summary>
		/// <param name="s">the string to represent
		/// </param>
		/// <param name="u">the unparsed representation
		/// 
		/// </param>
		public LogoWord(System.String s, System.String u)
		{
			_str = s;
			_unparsed = u;
			
			// Hack: Netscape wants to interpret the empty string as 0
			if (_str.Length == 0)
			{
				_type = TYPE_WORD;
			}
			else
			{
				try
				{
					_val = System.Double.Parse(_str);
					//UPGRADE_WARNING: Narrowing conversions may produce unexpected results in C#. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1042"'
					int intval = (int) _val;
					if (intval == _val)
					{
						_str = intval.ToString();
						_type = TYPE_INT;
					}
					else
					{
						_type = TYPE_FLOAT;
					}
				}
				catch (System.FormatException e)
				{
					_type = TYPE_WORD;
				}
			}
		}
		
		
		/// <summary> Construct a word with a given string
		/// *
		/// </summary>
		/// <param name="s">the string to represent
		/// 
		/// </param>
		public LogoWord(System.String s):this(s, null)
		{
		}
		
		
		/// <summary> Construct a word with a given caseless string and unparsed string info
		/// *
		/// </summary>
		/// <param name="s">the string to represent
		/// </param>
		/// <param name="u">the unparsed representation
		/// 
		/// </param>
		public LogoWord(CaselessString s, System.String u):this(s.str, u)
		{
		}
		
		
		/// <summary> Construct a word with a given caseless string
		/// *
		/// </summary>
		/// <param name="s">the string to represent
		/// 
		/// </param>
		public LogoWord(CaselessString s):this(s.str, null)
		{
		}
		
		
		/// <summary> Construct a word with a boolean
		/// *
		/// </summary>
		/// <param name="b">the boolean to represent
		/// 
		/// </param>
		public LogoWord(bool b)
		{
			if (b)
			{
				_unparsed = _true;
				_str = _true;
			}
			else
			{
				_unparsed = _false;
				_str = _false;
			}
			_type = TYPE_WORD;
		}
		
		
		/// <summary> Construct a word with a number
		/// *
		/// </summary>
		/// <param name="d">the double to represent
		/// 
		/// </param>
		public LogoWord(double n)
		{
			_val = n;
			//UPGRADE_WARNING: Narrowing conversions may produce unexpected results in C#. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1042"'
			int intval = (int) _val;
			if (intval == _val)
			{
				_unparsed = intval.ToString();
				_str = _unparsed;
				_type = TYPE_INT;
			}
			else
			{
				_unparsed = _val.ToString();
				_str = _unparsed;
				_type = TYPE_FLOAT;
			}
		}
		
		
		/// <summary> Construct a word with an integer
		/// *
		/// </summary>
		/// <param name="n">the integer to represent
		/// 
		/// </param>
		public LogoWord(int n)
		{
			_val = (double) n;
			_unparsed = n.ToString();
			_str = _unparsed;
			_type = TYPE_INT;
		}
		
		
		/// <summary> Construct a word given a punctuation character (used by Tokenizer)
		/// </summary>
		internal LogoWord(char c)
		{
			char[] ca = new char[1];
			ca[0] = c;
			_str = new System.String(ca);
			_unparsed = _str;
			_type = TYPE_PUNCT;
		}
		
		
		/// <summary> Construct a word given two punctuation characters (used by Tokenizer)
		/// </summary>
		internal LogoWord(char c1, char c2)
		{
			char[] ca = new char[2];
			ca[0] = c1;
			ca[1] = c2;
			_str = new System.String(ca);
			_unparsed = _str;
			_type = TYPE_PUNCT;
		}
		
		
		//UPGRADE_TODO: The equivalent of method 'java.lang.Object.clone' is not an override method. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1143"'
		/// <summary> Clone the object
		/// *
		/// </summary>
		/// <returns> a clone of this object
		/// 
		/// </returns>
		public override System.Object Clone() //Birb-JLCA: added "override"
		{
			return new LogoWord(_str, _unparsed, _type, _val);
		}
		
		
		/// <summary> Determine if another object is equal to this one
		/// *
		/// </summary>
		/// <param name="obj">what to compare with
		/// *
		/// </param>
		/// <returns> true iff equal
		/// 
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			if (obj is LogoWord)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				return CaselessString.staticEquals(_str, obj.ToString());
			}
			else
			{
				return false;
			}
		}
		
		
		/// <summary> Write to a string
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public override System.String ToString()
		{
			return _str;
		}
		
		
		/// <summary> Unparse word
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public override System.String unparse()
		{
			if (_unparsed == null)
			{
				_unparsed = CaselessString.staticUnparse(_str);
			}
			return _unparsed;
		}
		
		
		
		
		/// <summary> Copy the first character of the word
		/// *
		/// </summary>
		/// <returns> a new object containing first
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty word
		/// 
		/// </exception>
		public override LogoObject first()
		{
			try
			{
				return new LogoWord(_str.Substring(0, (1) - (0)));
			}
			catch (System.ArgumentOutOfRangeException e)
			{
				throw new LanguageException("Empty word");
			}
		}
		
		
		/// <summary> Copy the last character of the word
		/// *
		/// </summary>
		/// <returns> a new object containing last
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty word
		/// 
		/// </exception>
		public override LogoObject last()
		{
			try
			{
				return new LogoWord(_str.Substring(_str.Length - 1));
			}
			catch (System.ArgumentOutOfRangeException e)
			{
				throw new LanguageException("Empty word");
			}
		}
		
		
		/// <summary> Copy all parts except first
		/// *
		/// </summary>
		/// <returns> a new object containing butfirst
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty word
		/// 
		/// </exception>
		public override LogoObject butFirst()
		{
			try
			{
				return new LogoWord(_str.Substring(1));
			}
			catch (System.ArgumentOutOfRangeException e)
			{
				throw new LanguageException("Empty word");
			}
		}
		
		
		/// <summary> Copy all parts except last
		/// *
		/// </summary>
		/// <returns> a new object containing butfirst
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty word
		/// 
		/// </exception>
		public override LogoObject butLast()
		{
			try
			{
				return new LogoWord(_str.Substring(0, (_str.Length - 1) - (0)));
			}
			catch (System.ArgumentOutOfRangeException e)
			{
				throw new LanguageException("Empty word");
			}
		}
		
		
		/// <summary> Turns this word into a number
		/// *
		/// </summary>
		/// <returns> the number value
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException bad number format or list given
		/// 
		/// </exception>
		public override double toNumber()
		{
			if (_type == TYPE_INT || _type == TYPE_FLOAT)
			{
				return _val;
			}
			else
			{
				throw new LanguageException("Number expected");
			}
		}
		
		
		/// <summary> Turns this word into an integer
		/// *
		/// </summary>
		/// <returns> the number value
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException bad number format or list given
		/// 
		/// </exception>
		public override int toInteger()
		{
			if (_type == TYPE_INT)
			{
				//UPGRADE_WARNING: Narrowing conversions may produce unexpected results in C#. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1042"'
				return (int) _val;
			}
			else
			{
				throw new LanguageException("Integer expected");
			}
		}
		
		
		/// <summary> Turns this word into a boolean
		/// *
		/// </summary>
		/// <returns> the boolean value
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException bad boolean format or list given
		/// 
		/// </exception>
		public override bool toBoolean()
		{
			if (CaselessString.staticEquals(_str, _true))
			{
				return true;
			}
			else if (CaselessString.staticEquals(_str, _false))
			{
				return false;
			}
			else
			{
				throw new LanguageException("Boolean expression expected");
			}
		}
		
		
		/// <summary> Returns length of the word
		/// *
		/// </summary>
		/// <returns> the length
		/// 
		/// </returns>
		public override int length()
		{
			return _str.Length;
		}
		
		
		/// <summary> Pick the index'th character of the word (1-based)
		/// *
		/// </summary>
		/// <returns> a copy of the member
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException index out of bounds or empty object
		/// 
		/// </exception>
		public override LogoObject pick(int index)
		{
			if (_str.Length == 0)
			{
				throw new LanguageException("Empty word");
			}
			try
			{
				return new LogoWord(_str.Substring(index - 1, (index) - (index - 1)));
			}
			catch (System.ArgumentOutOfRangeException e)
			{
				throw new LanguageException("Index out of bounds");
			}
		}
	}
}