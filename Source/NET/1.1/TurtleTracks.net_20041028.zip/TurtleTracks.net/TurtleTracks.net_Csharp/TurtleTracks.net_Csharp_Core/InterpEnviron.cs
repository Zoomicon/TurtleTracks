/*
===============================================================================

FILE:  InterpEnviron.java

PROJECT:

Turtle Tracks

CONTENTS:

Interpreter environment object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	
	
	/// <summary> Interpreter environment data
	/// </summary>
	
	public sealed class InterpEnviron
	{
		/// <summary> Get the test state
		/// *
		/// </summary>
		/// <returns> true or false
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException the current test state is unset
		/// 
		/// </exception>
		/// <summary> Set the test state
		/// *
		/// </summary>
		/// <param name="val">true or false
		/// 
		/// </param>
		public bool TestResult //Birb-JLCA: removed "virtual"
		{
			get
			{
				if (_testState == - 1)
				{
					throw new LanguageException("No corresponding TEST statement");
				}
				return _testState == 1;
			}
			
			set
			{
				_testState = value?(sbyte) 1:(sbyte) 0;
			}
			
		}
		/// <summary> Get the test state (low level)
		/// *
		/// </summary>
		/// <returns> 1 for true, 0 for false, or -1 for unset
		/// 
		/// </returns>
		/// <summary> Set the test state (low level)
		/// *
		/// </summary>
		/// <param name="val">1 for true, 0 for false, or -1 for unset
		/// 
		/// </param>
		public sbyte TestState //Birb-JLCA: removed "virtual"
		{
			get
			{
				return _testState;
			}
			
			set
			{
				_testState = value;
			}
			
		}
		/// <summary> Get the repeat count
		/// *
		/// </summary>
		/// <returns> the repeat count
		/// 
		/// </returns>
		public int LoopIndex //Birb-JLCA: removed "virtual"
		{
			get
			{
				return _loopIndex;
			}
			
		}
		private sbyte _testState;
		private int _loopIndex;
		
		private InterpreterThread _thread;
		private Machine _mach;
		
		
		/// <summary> Construct an empty interpreter environment
		/// (used only by PrimitiveGroup's initializer)
		/// </summary>
		internal InterpEnviron()
		{
		}
		
		
		/// <summary> Construct a default interpreter environment, with an undefined test
		/// state and loop index.
		/// *
		/// </summary>
		/// <param name="t">the thread running
		/// 
		/// </param>
		public InterpEnviron(InterpreterThread t)
		{
			_testState = (sbyte) (- 1);
			_loopIndex = - 1;
			_thread = t;
			_mach = t.mach();
		}
		
		
		/// <summary> Construct an interpreter environment
		/// *
		/// </summary>
		/// <param name="ts">the test state (must be 0 for false, 1 for true, or -1 for unset)
		/// </param>
		/// <param name="li">the current repcount
		/// </param>
		/// <param name="t">the thread running
		/// 
		/// </param>
		public InterpEnviron(sbyte ts, int li, InterpreterThread t)
		{
			_testState = ts;
			_loopIndex = li;
			_thread = t;
			_mach = t.mach();
		}
		
		
		/// <summary> Construct an interpreter environment
		/// *
		/// </summary>
		/// <param name="env">the environment to copy
		/// 
		/// </param>
		public InterpEnviron(InterpEnviron env)
		{
			_testState = env._testState;
			_loopIndex = env._loopIndex;
			_thread = env._thread;
			_mach = env._mach;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		/// <summary> Accessor for machine
		/// *
		/// </summary>
		/// <returns> the machine
		/// 
		/// </returns>
		public Machine mach()
		{
			return _mach;
		}
		
		
		/// <summary> Accessor for thread
		/// *
		/// </summary>
		/// <returns> the thread
		/// 
		/// </returns>
		public InterpreterThread thread()
		{
			return _thread;
		}
	}
}