/*
===============================================================================

FILE:  ParseSpecial.java

PROJECT:

Turtle Tracks

CONTENTS:

Special node in a parse tree

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Special node in a parse tree
	/// </summary>
	
	class ParseSpecial:ParseObject
	{
		
		internal const int TO = 0;
		internal const int TOMACRO = 1;
		
		internal const System.String strEND = "END";
		internal const System.String strTO = "TO";
		internal const System.String strTOMACRO = "TOMACRO";
		
		
		//UPGRADE_NOTE: Final was removed from the declaration of '_objEND '. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1003"'
		private static readonly LogoWord _objEND = new LogoWord(strEND);
		private int _code;
		private LogoList _args;
		
		
		/// <summary> Construct the ParsePrimitive
		/// *
		/// </summary>
		/// <param name="code">either TO or TOMACRO
		/// </param>
		/// <param name="args">the arguments to TO.
		/// 
		/// </param>
		internal ParseSpecial(int code, LogoList args)
		{
			_code = code;
			_args = args;
		}
		
		
		//UPGRADE_TODO: The equivalent of method 'java.lang.Object.clone' is not an override method. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1143"'
		/// <summary> Clone the object
		/// *
		/// </summary>
		/// <returns> a clone of this object
		/// 
		/// </returns>
		public override System.Object Clone() //Birb-JLCA: added "override"
		{
			return new ParseSpecial(_code, _args);
		}
		
		
		/// <summary> Determine if another object is equal to this one
		/// *
		/// </summary>
		/// <param name="obj">what to compare with
		/// *
		/// </param>
		/// <returns> true iff equal
		/// 
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			return false;
		}
		
		
		/// <summary> Evaluate this object in the given environment
		/// *
		/// </summary>
		/// <param name="interp">the environment
		/// *
		/// </param>
		/// <returns> the return value (void)
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException error thrown
		/// 
		/// </exception>
		internal override LogoObject evaluate(InterpEnviron interp)
		{
			if (_code == TO)
			{
				pTO(interp, false);
			}
			else if (_code == TOMACRO)
			{
				pTO(interp, true);
			}
			else
			{
				throw new LanguageException("Internal error: unrecognized special form " + _code.ToString());
			}
			return LogoVoid.obj;
		}
		
		
		/// <summary> Primitive TO
		/// *
		/// </summary>
		/// <param name="interp">the environment
		/// </param>
		/// <param name="isMacro">true if user used TOMACRO
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException error thrown
		/// 
		/// </exception>
		private void  pTO(InterpEnviron interp, bool isMacro)
		{
			//UPGRADE_ISSUE: Method 'java.lang.Thread.yield' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javalangThreadyield"'
			Thread.yield();
			
			LogoObject obj = _args.pickInPlace(0);
			
			// Parse out and check procedure name
			if (!(obj is LogoWord))
			{
				throw new LanguageException("Procedure name expected");
			}
			LogoWord nameWord = (LogoWord) obj;
			if (nameWord.Type == LogoWord.TYPE_PUNCT || nameWord.Type == LogoWord.TYPE_INT || nameWord.Type == LogoWord.TYPE_FLOAT)
			{
				throw new LanguageException("Procedure name expected");
			}
			System.String checkName = nameWord.unparse();
			if (checkName.Length > 0)
			{
				if (checkName[0] == '\"')
				{
					throw new LanguageException("Procedure name should not be quoted");
				}
				if (checkName[0] == ':')
				{
					throw new LanguageException("Procedure name should not be preceded by a colon");
				}
			}
			CaselessString name = nameWord.toCaselessString();
			Procedure.checkName(name.str);
			if (!interp.mach().OverridePrimitives && interp.mach().isReserved(name))
			{
				throw new LanguageException("The name " + name.str + " is a primitive.");
			}
			if (!interp.thread().Loading)
			{
				if (interp.mach().resolveProc(name) != null)
				{
					throw new LanguageException("The procedure " + name.str + " is already defined.");
				}
			}
			
			// Parse out and check formal parameter names
			System.Collections.ArrayList vec = new System.Collections.ArrayList();
			int i;
			for (i = 1; i < _args.length(); i++)
			{
				obj = _args.pickInPlace(i);
				if (!(obj is LogoWord))
				{
					throw new LanguageException("Parameter name expected but list found.");
				}
				//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				checkName = obj.ToString();
				if (checkName.Length == 0)
				{
					throw new LanguageException("Parameter name must be preceded by a colon.");
				}
				if (checkName[0] != ':')
				{
					throw new LanguageException("Parameter name must be preceded by a colon");
				}
				vec.Add(new LogoWord(checkName.Substring(1)));
			}
			LogoList params_Renamed = new LogoList(vec);
			Procedure.checkParamNames(params_Renamed);
			
			// Ready to read
			Tokenizer tokenizer = new Tokenizer(interp.mach().TokenizerCommentFlags);
			vec = new System.Collections.ArrayList();
			System.Text.StringBuilder tester = new System.Text.StringBuilder();
			System.String lin;
			char promptChar = '>';
			while (true)
			{
				if (interp.thread().inStream().eof())
				{
					break;
				}
				if (interp.thread().Loading)
				{
					lin = interp.thread().inStream().Line;
				}
				else
				{
					lin = interp.mach().console().promptGetLine('>');
				}
				tester.Append(lin);
				if (tester.Length > 0)
				{
					if (tester[tester.Length - 1] == '~')
					{
						tester[tester.Length - 1] = ' ';
						promptChar = '~';
					}
					else
					{
						try
						{
							LogoList ll = tokenizer.tokenize(tester.ToString());
							//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
							if (ll.length() == 1 && CaselessString.staticEquals(ll.pickInPlace(0).ToString(), strEND))
							{
								break;
							}
							tester = new System.Text.StringBuilder();
							promptChar = '>';
						}
						catch (LanguageException e)
						{
							promptChar = e.ContChar;
							if (promptChar == '|' || promptChar == '\\' || promptChar == '~')
							{
								tester.Append(Machine.LINE_SEPARATOR);
							}
							else
							{
								throw e;
							}
						}
					}
				}
				vec.Add(lin);
			}
			
			// Define procedure
			Procedure proc = new Procedure(interp.mach(), name, params_Renamed, vec, isMacro);
			interp.mach().defineProc(proc);
			interp.mach().console().putStatusMessage(name.str + " defined.");
		}
	}
}