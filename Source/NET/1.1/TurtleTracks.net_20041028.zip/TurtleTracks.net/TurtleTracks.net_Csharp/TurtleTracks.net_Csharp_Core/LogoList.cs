/*
===============================================================================

FILE:  LogoList.java

PROJECT:

Turtle Tracks

CONTENTS:

List logo object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Logo List object
	/// </summary>
	
	public class LogoList:LogoObject
	{
		
		private LogoObject[] _lis;
		private ParseTree _run;
		
		
		/// <summary> Construct an empty list
		/// </summary>
		public LogoList()
		{
			_lis = new LogoObject[0];
			_run = null;
		}
		
		
		/// <summary> Construct a list with a given LogoObject array.
		/// *
		/// </summary>
		/// <param name="a">array to use
		/// 
		/// </param>
		public LogoList(LogoObject[] a)
		{
			_lis = a;
			_run = null;
		}
		
		
		/// <summary> Construct a list with a given vector of LogoObjects
		/// *
		/// </summary>
		/// <param name="v">vector to use
		/// 
		/// </param>
		public LogoList(System.Collections.ArrayList v)
		{
			_lis = new LogoObject[v.Count];
			int i;
			for (i = 0; i < _lis.Length; i++)
			{
				_lis[i] = (LogoObject) (v[i]);
			}
			_run = null;
		}
		
		
		//UPGRADE_TODO: The equivalent of method 'java.lang.Object.clone' is not an override method. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1143"'
		/// <summary> Clone the object
		/// *
		/// </summary>
		/// <returns> a clone of this object
		/// 
		/// </returns>
		public override System.Object Clone() //Birb-JLCA: added "override"
		{
			int i;
			LogoObject[] a = new LogoObject[_lis.Length];
			
			for (i = 0; i < _lis.Length; i++)
			{
				a[i] = _lis[i];
			}
			return new LogoList(a);
		}
		
		
		/// <summary> Determine if another object is equal to this one
		/// *
		/// </summary>
		/// <param name="obj">what to compare with
		/// *
		/// </param>
		/// <returns> true iff equal
		/// 
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			if (obj is LogoList)
			{
				if (((LogoList) obj).length() != _lis.Length)
				{
					return false;
				}
				else
				{
					int i;
					
					for (i = 0; i < _lis.Length; i++)
					{
						if (!(_lis[i].Equals(((LogoList) obj)._lis[i])))
						{
							return false;
						}
					}
					return true;
				}
			}
			else
			{
				return false;
			}
		}
		
		
		/// <summary> Convert to a string, for display purposes.
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public override System.String ToString()
		{
			int i;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			
			sb.Append('[').Append(' ');
			for (i = 0; i < _lis.Length; i++)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				sb.Append(_lis[i].ToString()).Append(' ');
			}
			sb.Append(']');
			
			return sb.ToString();
		}
		
		
		/// <summary> Unparse list. Emits escape sequences.
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public override System.String unparse()
		{
			int i;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			
			sb.Append('[').Append(' ');
			for (i = 0; i < _lis.Length; i++)
			{
				sb.Append(_lis[i].unparse()).Append(' ');
			}
			sb.Append(']');
			
			return new System.String(sb.ToString().ToCharArray());
		}
		
		
		/// <summary> Convert to a string with no enclosing brackets
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public virtual System.String toStringOpen()
		{
			int i;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			
			for (i = 0; i < _lis.Length; i++)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				sb.Append(_lis[i].ToString());
				if (i != _lis.Length - 1)
					sb.Append(' ');
			}
			
			return sb.ToString();
		}
		
		
		/// <summary> Returns a list that has been retokenized for running
		/// *
		/// </summary>
		/// <param name="mach">the machine to parse with
		/// 
		/// </param>
		/// <returns> the parse tree
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException unable to parse
		/// 
		/// </exception>
		public override ParseTree getRunnable(Machine mach)
		{
			if (_run != null)
			{
				if (_run.testClock(mach.Clock))
				{
					return _run;
				}
			}
			_run = (new Parser()).parse(this, mach);
			return _run;
		}
		
		
		/// <summary> Copy the first element of the list
		/// *
		/// </summary>
		/// <returns> an object containing first
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty list
		/// 
		/// </exception>
		public override LogoObject first()
		{
			if (_lis.Length == 0)
			{
				throw new LanguageException("Empty list");
			}
			return _lis[0];
		}
		
		
		/// <summary> Copy the last element of the list
		/// *
		/// </summary>
		/// <returns> an object containing last
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty list
		/// 
		/// </exception>
		public override LogoObject last()
		{
			if (_lis.Length == 0)
			{
				throw new LanguageException("Empty list");
			}
			return _lis[_lis.Length - 1];
		}
		
		
		/// <summary> Copy all parts except first
		/// *
		/// </summary>
		/// <returns> an object containing butfirst
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty list
		/// 
		/// </exception>
		public override LogoObject butFirst()
		{
			if (_lis.Length == 0)
			{
				throw new LanguageException("Empty list");
			}
			
			int i;
			LogoObject[] a = new LogoObject[_lis.Length - 1];
			
			for (i = 1; i < _lis.Length; i++)
			{
				a[i - 1] = _lis[i];
			}
			return new LogoList(a);
		}
		
		
		/// <summary> Copy all parts except last
		/// *
		/// </summary>
		/// <returns> a new object containing butlast
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException object is an empty list
		/// 
		/// </exception>
		public override LogoObject butLast()
		{
			if (_lis.Length == 0)
			{
				throw new LanguageException("Empty list");
			}
			
			int i;
			LogoObject[] a = new LogoObject[_lis.Length - 1];
			
			for (i = 0; i < _lis.Length - 1; i++)
			{
				a[i] = _lis[i];
			}
			return new LogoList(a);
		}
		
		
		/// <summary> Inserts given object at front of list, and returns new list
		/// *
		/// </summary>
		/// <param name="obj">the object to insert
		/// *
		/// </param>
		/// <returns> a new object containing fput
		/// 
		/// </returns>
		public virtual LogoObject fput(LogoObject obj)
		{
			if (obj is LogoVoid)
			{
				return this;
			}
			else
			{
				int i;
				LogoObject[] a = new LogoObject[_lis.Length + 1];
				
				a[0] = obj;
				for (i = 0; i < _lis.Length; i++)
				{
					a[i + 1] = _lis[i];
				}
				return new LogoList(a);
			}
		}
		
		
		/// <summary> Inserts given object at back of list, and returns new list
		/// *
		/// </summary>
		/// <param name="obj">the object to insert
		/// *
		/// </param>
		/// <returns> a new object containing lput
		/// 
		/// </returns>
		public virtual LogoObject lput(LogoObject obj)
		{
			if (obj is LogoVoid)
			{
				return this;
			}
			else
			{
				int i;
				LogoObject[] a = new LogoObject[_lis.Length + 1];
				
				for (i = 0; i < _lis.Length; i++)
				{
					a[i] = _lis[i];
				}
				a[_lis.Length] = obj;
				return new LogoList(a);
			}
		}
		
		
		/// <summary> Returns length of the object
		/// *
		/// </summary>
		/// <returns> the length
		/// 
		/// </returns>
		public override int length()
		{
			return _lis.Length;
		}
		
		
		/// <summary> Is given object a member of this list
		/// *
		/// </summary>
		/// <returns> true iff member
		/// 
		/// </returns>
		public virtual bool isMember(LogoObject obj)
		{
			int i;
			
			for (i = 0; i < _lis.Length; i++)
			{
				if (_lis[i].Equals(obj))
				{
					return true;
				}
			}
			
			return false;
		}
		
		
		/// <summary> Pick the index'th member of the list
		/// *
		/// </summary>
		/// <param name="index">1-based index
		/// *
		/// </param>
		/// <returns> a copy of the member
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException index out of bounds or empty object
		/// 
		/// </exception>
		public override LogoObject pick(int index)
		{
			if (_lis.Length == 0)
			{
				throw new LanguageException("Empty list");
			}
			if (index < 1 || index > _lis.Length)
			{
				throw new LanguageException("Index out of bounds");
			}
			return _lis[index - 1];
		}
		
		
		/// <summary> Pick the index'th member of the list. Throws ArrayIndexOutOfBoundsException
		/// instead of LanguageException for index out of bounds
		/// *
		/// </summary>
		/// <param name="index">0-based index
		/// *
		/// </param>
		/// <returns> the member
		/// 
		/// </returns>
		public virtual LogoObject pickInPlace(int index)
		{
			return _lis[index];
		}
	}
}