/*
===============================================================================

FILE:  ParseProcedure.java

PROJECT:

Turtle Tracks

CONTENTS:

Procedure node in a parse tree

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	
	
	/// <summary> Procedure node in a parse tree
	/// </summary>
	
	public class ParseProcedure:ParseObject
	{
		
		private Procedure _proc;
		private ParseObject[] _args;
		
		
		/// <summary> Constructor
		/// *
		/// </summary>
		/// <param name="proc">the procedure to call
		/// </param>
		/// <param name="args">the arguments, as parse tree node
		/// 
		/// </param>
		public ParseProcedure(Procedure proc, ParseObject[] args)
		{
			_proc = proc;
			_args = args;
		}
		
		
		//UPGRADE_TODO: The equivalent of method 'java.lang.Object.clone' is not an override method. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1143"'
		/// <summary> Clone the object
		/// *
		/// </summary>
		/// <returns> a clone of this object
		/// 
		/// </returns>
		public override System.Object Clone() //Birb-JLCA: added "override"
		{
			return new ParseProcedure(_proc, _args);
		}
		
		
		/// <summary> Determine if another object is equal to this one
		/// *
		/// </summary>
		/// <param name="obj">what to compare with
		/// *
		/// </param>
		/// <returns> true iff equal
		/// 
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			return false;
		}
		
		
		/// <summary> The name of the procedure
		/// *
		/// </summary>
		/// <returns> the name
		/// 
		/// </returns>
		internal override System.String procName()
		{
			return _proc.Name.str;
		}
		
		
		/// <summary> Evaluate this object in the given environment
		/// *
		/// </summary>
		/// <param name="interp">the environment
		/// *
		/// </param>
		/// <returns> the return value
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.csharp.ThrowException exception thrown
		/// 
		/// </exception>
		internal override LogoObject evaluate(InterpEnviron interp)
		{
			// Evaluate arguments
			LogoObject[] evalArgs = new LogoObject[_args.Length];
			for (int i = 0; i < _args.Length; i++)
			{
				evalArgs[i] = _args[i].evaluate(interp);
				if (evalArgs[i] == LogoVoid.obj)
				{
					throw new LanguageException(_args[i].procName().ToUpper() + " didn't output to " + _proc.Name.str.ToUpper());
				}
			}
			
			// Check for thread suspension and termination
			//UPGRADE_ISSUE: Method 'java.lang.Thread.yield' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javalangThreadyield"'
			Thread.yield();
			interp.mach().checkSuspend();
			if (interp.thread().stopping())
			{
				throw new ThrowException(".SUDDENSTOPTHREAD");
			}
			
			// Set up new stack frame
			LogoObject ret = LogoVoid.obj;
			LogoList paramNames = _proc.Params;
			SymbolTable local = new SymbolTable();
			for (int i = 0; i < paramNames.length(); i++)
			{
				local.makeForced(paramNames.pickInPlace(i).toCaselessString(), evalArgs[i]);
			}
			InterpEnviron interp2 = new InterpEnviron(interp);
			interp.thread().enterProcedure(local);
			
			// Invoke procedure
			LogoObject obj = LogoVoid.obj;
			try
			{
				obj = _proc.Code.getRunnable(interp.mach()).execute(interp2);
			}
			catch (ThrowException e)
			{
				if (!_proc.Macro && e.Tag.Equals("STOP"))
				{
					ret = e.Obj;
				}
				else
				{
					throw e;
				}
			}
			catch (LanguageException e)
			{
				if (e.ProcName == null)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.Message, e.PrimName, _proc.Name.ToString(), e.ContChar);
				}
				else
				{
					throw e;
				}
			}
			finally
			{
				interp.thread().exitProcedure();
			}
			if (_proc.Macro)
			{
				ret = obj;
			}
			else if (!interp.mach().AutoIgnore && obj != LogoVoid.obj)
			{
				throw new LanguageException("You don't say what to do with " + obj);
			}
			return ret;
		}
	}
}