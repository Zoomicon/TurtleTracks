/*
===============================================================================

FILE:  Parser.java

PROJECT:

Turtle Tracks

CONTENTS:

Parser object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Parser. Generates a ParseTree from a LogoList.
	/// </summary>
	
	sealed class Parser
	{
		
		private static System.String STRING_OPEN_PAREN = "(";
		private static System.String STRING_CLOSE_PAREN = ")";
		
		private int _index;
		private LogoList _list;
		private Machine _mach;
		private bool _paren;
		
		private LogoObject _next;
		private LogoWord _nextw;
		private LogoList _nextl;
		
		
		/// <summary> Parse the given list (interface)
		/// *
		/// </summary>
		/// <param name="l">The list to interpret
		/// </param>
		/// <param name="mach">the machine to interpret in
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException language error
		/// 
		/// </exception>
		internal ParseTree parse(LogoList ll, Machine mach)
		{
			_mach = mach;
			_list = new Tokenizer(0).tokenizeRunnable(ll);
			_index = 0;
			nextWord();
			
			if (_next == LogoVoid.obj)
			{
				return new ParseTree(- 1, new ParseObject[0]);
			}
			else if (_next.toCaselessString().Equals(ParseSpecial.strTO))
			{
				ParseObject[] a = new ParseObject[1];
				a[0] = new ParseSpecial(ParseSpecial.TO, (LogoList) (_list.butFirst()));
				return new ParseTree(- 1, a);
			}
			else if (_next.toCaselessString().Equals(ParseSpecial.strTOMACRO))
			{
				ParseObject[] a = new ParseObject[1];
				a[0] = new ParseSpecial(ParseSpecial.TOMACRO, (LogoList) (_list.butFirst()));
				return new ParseTree(- 1, a);
			}
			else
			{
				System.Collections.ArrayList vec = new System.Collections.ArrayList();
				int clock;
				lock (_mach)
				{
					clock = _mach.Clock;
					while (_next != LogoVoid.obj)
					{
						vec.Add(parseD());
					}
				}
				return new ParseTree(clock, vec);
			}
		}
		
		
		/// <summary> Utility for creating a primitive node with two parameters
		/// Only for use with infix operators (TYPE_PUNCT)
		/// </summary>
		private ParseObject createPrimitive(System.String n, ParseObject param1, ParseObject param2)
		{
			PrimitiveSpec prim = _mach.findPrimitive(new CaselessString(n));
			if (prim != null)
			{
				ParseObject[] params_Renamed = new ParseObject[2];
				params_Renamed[0] = param1;
				params_Renamed[1] = param2;
				return new ParsePrimitive(prim, n, params_Renamed);
			}
			else
			{
				throw new LanguageException("Fatal error: no primitive for " + n);
			}
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseC()
		{
			if (_nextw != null)
			{
				if (_nextw.Type == LogoWord.TYPE_WORD)
				{
					PrimitiveSpec prim = null;
					Procedure proc = null;
					int max;
					CaselessString name = _nextw.toCaselessString();
					
					proc = _mach.resolveProc(name);
					if (proc != null)
					{
						max = proc.numArgs();
					}
					else
					{
						prim = _mach.findPrimitive(name);
						if (prim != null)
						{
							max = prim.numArgs();
						}
						else
						{
							throw new LanguageException("I don't know how to " + name);
						}
					}
					
					nextWord();
					ParseObject[] params_Renamed;
					int i;
					if (_paren)
					{
						System.Collections.ArrayList v = new System.Collections.ArrayList();
						while (true)
						{
							if (_nextw != null)
							{
								//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
								if (_nextw.Type == LogoWord.TYPE_PUNCT && !_nextw.ToString().Equals(STRING_OPEN_PAREN))
								{
									break;
								}
							}
							v.Add(parseD());
						}
						params_Renamed = new ParseObject[v.Count];
						for (i = 0; i < v.Count; i++)
						{
							params_Renamed[i] = (ParseObject) (v[i]);
						}
					}
					else
					{
						params_Renamed = new ParseObject[max];
						for (i = 0; i < max; i++)
						{
							params_Renamed[i] = parseD();
						}
					}
					
					if (proc != null)
					{
						return new ParseProcedure(proc, params_Renamed);
					}
					else
					{
						return new ParsePrimitive(prim, name.str, params_Renamed);
					}
				}
			}
			
			return parseD();
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseD()
		{
			ParseObject ret;
			bool oldParen = _paren;
			_paren = false;
			try
			{
				ret = parseDp(parseE());
			}
			finally
			{
				_paren = oldParen;
			}
			return ret;
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseDParen()
		{
			ParseObject ret;
			bool oldParen = _paren;
			_paren = true;
			try
			{
				ret = parseDp(parseE());
			}
			finally
			{
				_paren = oldParen;
			}
			return ret;
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseDp(ParseObject prevObj)
		{
			if (_nextw != null)
			{
				if (_nextw.Type == LogoWord.TYPE_PUNCT)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					System.String cmd = _nextw.ToString();
					if (cmd.Equals("=") || cmd.Equals(">") || cmd.Equals("<") || cmd.Equals(">=") || cmd.Equals("<="))
					{
						nextWord();
						return parseDp(createPrimitive(cmd, prevObj, parseE()));
					}
				}
			}
			
			return prevObj;
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseE()
		{
			return parseEp(parseT());
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseEp(ParseObject prevObj)
		{
			if (_nextw != null)
			{
				if (_nextw.Type == LogoWord.TYPE_PUNCT)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					System.String cmd = _nextw.ToString();
					if (cmd.Equals("+") || cmd.Equals("-"))
					{
						nextWord();
						return parseEp(createPrimitive(cmd, prevObj, parseT()));
					}
				}
			}
			
			return prevObj;
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseT()
		{
			return parseTp(parseF());
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseTp(ParseObject prevObj)
		{
			if (_nextw != null)
			{
				if (_nextw.Type == LogoWord.TYPE_PUNCT)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					System.String cmd = _nextw.ToString();
					if (cmd.Equals("*") || cmd.Equals("/"))
					{
						nextWord();
						return parseTp(createPrimitive(cmd, prevObj, parseF()));
					}
				}
			}
			
			return prevObj;
		}
		
		
		/// <summary> Part of the parser
		/// </summary>
		private ParseObject parseF()
		{
			ParseObject ret = LogoVoid.obj;
			
			if (_nextw != null)
			{
				// Punctuation (open paren)
				if (_nextw.Type == LogoWord.TYPE_PUNCT)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					System.String cmd = _nextw.ToString();
					if (cmd.Equals(STRING_OPEN_PAREN))
					{
						nextWord();
						ret = parseDParen();
						if (_nextw == null)
						{
							throw new LanguageException("Missing closing paren", '(');
						}
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						if (!_nextw.ToString().Equals(STRING_CLOSE_PAREN))
						{
							throw new LanguageException("Closing paren expected");
						}
						nextWord();
						return ret;
					}
					else if (cmd.Equals(STRING_CLOSE_PAREN))
					{
						throw new LanguageException("Unexpected closing paren");
					}
					else if (!(cmd.Equals("-")))
					{
						throw new LanguageException("Not enough inputs to " + _nextw);
					}
				}
				
				// Numeric literal
				if (_nextw.Type == LogoWord.TYPE_FLOAT || _nextw.Type == LogoWord.TYPE_INT)
				{
					ret = _next;
					nextWord();
					return ret;
				}
				
				// Prefix function
				//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				System.String str = _nextw.ToString();
				if (str.Length > 0)
				{
					if (str.Equals("-"))
					{
						nextWord();
						PrimitiveSpec prim = _mach.findPrimitive(new CaselessString("MINUS"));
						if (prim == null)
						{
							throw new LanguageException("Fatal error: no primitive for operator -");
						}
						ParseObject[] params_Renamed = new ParseObject[1];
						params_Renamed[0] = parseF();
						return new ParsePrimitive(prim, "-", params_Renamed);
					}
					else if (str[0] == '\"')
					{
						ret = _next.butFirst();
						nextWord();
						return ret;
					}
					else if (str[0] == ':')
					{
						PrimitiveSpec prim = _mach.findPrimitive(new CaselessString("THING"));
						if (prim == null)
						{
							throw new LanguageException("Fatal error: no primitive for operator :");
						}
						ParseObject[] params_Renamed = new ParseObject[1];
						params_Renamed[0] = _next.butFirst();
						ret = new ParsePrimitive(prim, null, params_Renamed);
						nextWord();
						return ret;
					}
					else
					{
						return parseC();
					}
				}
				
				// Problem
				throw new LanguageException("Empty word in list");
			}
			// List literal
			else if (_nextl != null)
			{
				ret = _next;
				nextWord();
				return ret;
			}
			// End of list
			else
			{
				throw new LanguageException("Not enough inputs");
			}
		}
		
		
		/// <summary> Get next word in the list
		/// </summary>
		private void  nextWord()
		{
			if (_index >= _list.length())
			{
				_next = LogoVoid.obj;
				_nextw = null;
				_nextl = null;
			}
			else
			{
				_next = _list.pickInPlace(_index++);
				if (_next is LogoWord)
				{
					_nextw = (LogoWord) _next;
					_nextl = null;
				}
				else
				{
					_nextw = null;
					_nextl = (LogoList) _next;
				}
			}
		}
	}
}