/*
===============================================================================

FILE:  IORandomFile.java

PROJECT:

Turtle Tracks

CONTENTS:

Random-access file object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Stream that reads and writes to a file
	/// </summary>
	
	public class IORandomFile : IORandom
	{
		/// <summary> Is the stream open?
		/// *
		/// </summary>
		/// <returns> true iff can interact with stream
		/// 
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isOpen'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public bool Open
		{
			get
			{
				lock (this)
				{
					return (_file != null);
				}
			}
			
		}
		/// <summary> Get a line from the stream
		/// *
		/// </summary>
		/// <returns> the string
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getLine'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public System.String Line
		{
			get
			{
				lock (this)
				{
					if (_file == null)
					{
						throw new LanguageException("Stream is closed");
					}
					try
					{
						//UPGRADE_ISSUE: Method 'java.io.RandomAccessFile.readLine' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javaioRandomAccessFilereadLine"'
						System.String str = _file.readLine();
						if (str == null)
						{
							str = "";
						}
						int len = str.Length;
						if (len > 0 && str[len - 1] == '\r')
						{
							str = str.Substring(0, (len - 1) - (0));
						}
						else if (len > 0 && str[len - 1] == '\n')
						{
							if (len > 1 && str[len - 2] == '\r')
							{
								str = str.Substring(0, (len - 2) - (0));
							}
							else
							{
								str = str.Substring(0, (len - 1) - (0));
							}
						}
						return str;
					}
					catch (System.IO.IOException e)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException(e.ToString());
					}
				}
			}
			
		}
		/// <summary> Get a character from the stream
		/// *
		/// </summary>
		/// <returns> char the character
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getChar'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public char Char
		{
			get
			{
				lock (this)
				{
					if (_file == null)
					{
						throw new LanguageException("Stream is closed");
					}
					try
					{
						int c = _file.ReadByte();
						return (c == - 1)?'\x0000':(char) c;
					}
					catch (System.IO.IOException e)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException(e.ToString());
					}
				}
			}
			
		}
		
		private static LogoObject _kind;
		
		private LogoObject _name;
		private System.IO.FileStream _file;
		
		
		
		
		/// <summary> Constructor
		/// *
		/// </summary>
		/// <param name="f">file to open
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException unable to open file
		/// 
		/// </exception>
		public IORandomFile(System.IO.FileInfo f)
		{
			try
			{
				_name = new LogoWord(f.FullName);
				_file = SupportClass.RandomAccessFileSupport.CreateRandomAccessFile(f, "rw");
			}
			catch (System.IO.IOException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				throw new LanguageException("Couldn't open file: \"" + f.FullName + "\" I/O: " + e.Message);
			}
			catch (System.Security.SecurityException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
				throw new LanguageException("Couldn't open file: \"" + f.FullName + "\" Security: " + e.ToString());
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'close'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Close the stream
		/// *
		/// </summary>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException can't close
		/// 
		/// </exception>
		public virtual void  close()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream already closed");
				}
				try
				{
					_file.Close();
					_file = null;
				}
				catch (System.IO.IOException e)
				{
				}
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'name'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get the name of this object
		/// *
		/// </summary>
		/// <returns> the name as a LogoObject
		/// 
		/// </returns>
		public virtual LogoObject name()
		{
			lock (this)
			{
				return _name;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'kind'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get the kind of this object
		/// *
		/// </summary>
		/// <returns> the kind as a LogoObject
		/// 
		/// </returns>
		public virtual LogoObject kind()
		{
			lock (this)
			{
				return _kind;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eof'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Has the stream encountered EOF?
		/// *
		/// </summary>
		/// <returns> true iff eof encountered
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException stream closed
		/// 
		/// </exception>
		public virtual bool eof()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					return _file.Position >= _file.Length;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getAvailable'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get all available data from stream
		/// *
		/// </summary>
		/// <param name="buf">buffer to read into
		/// *
		/// </param>
		/// <returns> how much data was actually read
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		public virtual int getAvailable(char[] buf)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					sbyte[] inbuf = new sbyte[buf.Length];
					int len = SupportClass.ReadInput(_file, ref inbuf, 0, inbuf.Length);
					for (int i = 0; i < len; i++)
					{
						buf[i] = (char) (inbuf[i] & 0xff);
					}
					return len;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'charAvail'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Character available on stream?
		/// *
		/// </summary>
		/// <returns> true iff available
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		public virtual bool charAvail()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					return _file.Position < _file.Length;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a string to the stream
		/// *
		/// </summary>
		/// <param name="str">the string
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(System.String str)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					SupportClass.RandomAccessFileSupport.WriteBytes(str, _file);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'putLine'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a string to the stream
		/// *
		/// </summary>
		/// <param name="str">the string
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  putLine(System.String str)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					SupportClass.RandomAccessFileSupport.WriteBytes(str, _file);
					SupportClass.RandomAccessFileSupport.WriteBytes(Machine.LINE_SEPARATOR, _file);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a char to the stream
		/// *
		/// </summary>
		/// <param name="c">the char
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(char c)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					_file.WriteByte((byte) c);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a char array to the stream
		/// *
		/// </summary>
		/// <param name="buf">the buffer
		/// </param>
		/// <param name="num">number of characters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(char[] buf, int num)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					SupportClass.RandomAccessFileSupport.WriteBytes(new System.String(buf, 0, num), _file);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'flush'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Flush the stream
		/// *
		/// </summary>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  flush()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'seek'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Seek to a location in the file
		/// *
		/// </summary>
		/// <param name="pos">position in the stream
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  seek(long pos)
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					_file.Seek(pos, System.IO.SeekOrigin.Begin);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'tell'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Tell current location in the file
		/// *
		/// </summary>
		/// <returns> position in the stream
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual long tell()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					return _file.Position;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'length'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get length of file
		/// *
		/// </summary>
		/// <returns> length
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual long length()
		{
			lock (this)
			{
				if (_file == null)
				{
					throw new LanguageException("Stream is closed");
				}
				try
				{
					return _file.Length;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		static IORandomFile()
		{
			{
				_kind = new LogoWord("RANDOMFILE");
			}
		}
	}
}