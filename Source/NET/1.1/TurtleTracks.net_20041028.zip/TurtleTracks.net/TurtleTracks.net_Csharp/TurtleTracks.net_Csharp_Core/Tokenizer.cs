/*
===============================================================================

FILE:  Tokenizer.java

PROJECT:

Turtle Tracks

CONTENTS:

List builder object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> List builder
	/// </summary>
	
	public sealed class Tokenizer
	{
		/// <summary> Is current character a whitespace character
		/// </summary>
		private bool WhiteSpace
		{
			get
			{
				return (_ch == ' ' || _ch == '\t' || _ch == '\n' || _ch == '\r');
			}
			
		}
		/// <summary> Is current character a comment delimiter
		/// </summary>
		private bool Comment
		{
			get
			{
				return ((_flags & HONOR_COMMENTS) != 0 && _ch == ';' || (_ch == '#' && (_flags & HASH_COMMENT) != 0));
			}
			
		}
		
		private int _index;
		private System.String _str;
		private char _ch;
		private int _flags;
		
		
		public const int HONOR_COMMENTS = 1;
		public const int HASH_COMMENT = 2;
		
		
		/// <summary> Constructor
		/// *
		/// </summary>
		/// <param name="flags">flags used for tokenizing
		/// 
		/// </param>
		public Tokenizer(int flags)
		{
			_flags = flags;
		}
		
		
		/// <summary> Interface method: build a list given a string
		/// *
		/// </summary>
		/// <param name="s">the string to parse
		/// *
		/// </param>
		/// <returns> the LogoList generated
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parse error
		/// 
		/// </exception>
		public LogoList tokenize(System.String s)
		{
			//Birb: unused// int i;
			
			_index = 0;
			_str = s;
			nextChar();
			
			return new LogoList(build(true));
		}
		
		
		/// <summary> Interface method: build a runnable list given a LogoList
		/// *
		/// </summary>
		/// <param name="ll">the list to reparse
		/// *
		/// </param>
		/// <returns> the LogoRunnableList generated, in LogoList form
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parse error
		/// 
		/// </exception>
		internal LogoList tokenizeRunnable(LogoList ll)
		{
			System.Collections.ArrayList lis = new System.Collections.ArrayList();
			int i;
			
			for (i = 0; i < ll.length(); i++)
			{
				LogoObject obj = ll.pickInPlace(i);
				if (obj is LogoList)
				{
					lis.Add(obj);
				}
				else if (obj is LogoWord)
				{
					if (((LogoWord) obj).Type == LogoWord.TYPE_WORD)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						System.String str = obj.ToString();
						if (str.Length > 0)
							if (str[0] == ';')
							{
								break;
							}
						_index = 0;
						_str = obj.unparse();
						nextChar();
						buildRunnable(lis);
					}
					else
					{
						lis.Add(obj);
					}
				}
			}
			return new LogoList(lis);
		}
		
		
		/// <summary> Internal method: build a list with current string and position
		/// *
		/// </summary>
		/// <param name="toplevel">true iff we're at the top level of the parse
		/// *
		/// </param>
		/// <returns> the LogoList generated
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parse error
		/// 
		/// </exception>
		private System.Collections.ArrayList build(bool toplevel)
		{
			//Birb: unused// byte type;
			System.Text.StringBuilder sb;
			System.Text.StringBuilder usb;
			System.Collections.ArrayList lis = new System.Collections.ArrayList();
			
			while (true)
			{
				skipWhiteSpace();
				switch (_ch)
				{
					
					case '[': 
						nextChar();
						lis.Add(new LogoList(build(false)));
						break;
					
					case ']': 
						if (toplevel)
						{
							throw new LanguageException("Unmatched closing bracket");
						}
						else
						{
							nextChar();
							return lis;
						}
						goto case (char) (0);
					
					
					case (char) (0): 
						if (!toplevel)
						{
							throw new LanguageException("Unmatched opening bracket", '~');
						}
						else
						{
							return lis;
						}
						goto default;
					
					
					default: 
						if (Comment)
						{
							while (_ch != '\n' && _ch != '\r' && _ch != 0)
							{
								nextChar();
							}
							break;
						}
						sb = new System.Text.StringBuilder();
						usb = new System.Text.StringBuilder();
						while (true)
						{
							if (WhiteSpace || _ch == '[' || _ch == ']' || _ch == 0)
							{
								break;
							}
							if (Comment)
							{
								break;
							}
							usb.Append(_ch);
							if (_ch == '\\')
							{
								nextChar();
								if (_ch == 0)
								{
									throw new LanguageException("Hanging backslash", '\\');
								}
								usb.Append(_ch);
								appendEscape(sb);
								nextChar();
							}
							else if (_ch == '|')
							{
								nextChar();
								while (true)
								{
									if (_ch == 0)
									{
										throw new LanguageException("Unmatched \"|\"", '|');
									}
									usb.Append(_ch);
									if (_ch == '|')
									{
										nextChar();
										break;
									}
									else
									{
										sb.Append(_ch);
										nextChar();
									}
								}
							}
							else
							{
								sb.Append(_ch);
								nextChar();
							}
						}
						lis.Add(new LogoWord(sb.ToString(), usb.ToString()));
						break;
					
				}
			}
		}
		
		
		/// <summary> Internal method: build a list with current string and position
		/// *
		/// </summary>
		/// <param name="lis">the LogoList generated
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException parse error
		/// 
		/// </exception>
		private void  buildRunnable(System.Collections.ArrayList lis)
		{
			System.Text.StringBuilder sb;
			System.Text.StringBuilder usb;
			bool starting = true;
			
			while (true)
			{
				switch (_ch)
				{
					
					case '(': 
					case ')': 
					case '+': 
					case '*': 
					case '/': 
					case '=': 
						lis.Add(new LogoWord(_ch));
						starting = (_ch == '(');
						nextChar();
						break;
					
					
					case '-': 
						nextChar();
						if (starting && !WhiteSpace && _ch != '\x0000')
						{
							lis.Add(new LogoWord("-", "-"));
						}
						else
						{
							lis.Add(new LogoWord('-'));
						}
						starting = false;
						break;
					
					
					case '<': 
						nextChar();
						if (_ch == '=')
						{
							lis.Add(new LogoWord('<', '='));
							nextChar();
						}
						else
						{
							lis.Add(new LogoWord('<'));
						}
						starting = false;
						break;
					
					
					case '>': 
						nextChar();
						if (_ch == '=')
						{
							lis.Add(new LogoWord('>', '='));
							nextChar();
						}
						else
						{
							lis.Add(new LogoWord('>'));
						}
						starting = false;
						break;
					
					
					case (char) (0): 
						return ;
					
					
					default: 
						bool quoted = (_ch == '\"');
						sb = new System.Text.StringBuilder();
						usb = new System.Text.StringBuilder();
						while (true)
						{
							if (WhiteSpace || _ch == 0 || _ch == '(' || _ch == ')')
							{
								break;
							}
							if (!quoted)
							{
								if (_ch == '*' || _ch == '/' || _ch == '+' || _ch == '-' || _ch == '=' || _ch == '<' || _ch == '>')
								{
									break;
								}
							}
							usb.Append(_ch);
							if (_ch == '\\')
							{
								nextChar();
								if (_ch == 0)
								{
									throw new LanguageException("Hanging backslash", '\\');
								}
								usb.Append(_ch);
								appendEscape(sb);
								nextChar();
							}
							else if (_ch == '|')
							{
								nextChar();
								while (true)
								{
									if (_ch == 0)
									{
										throw new LanguageException("Unmatched \"|\"", '|');
									}
									usb.Append(_ch);
									if (_ch == '|')
									{
										nextChar();
										break;
									}
									else
									{
										sb.Append(_ch);
										nextChar();
									}
								}
							}
							else
							{
								sb.Append(_ch);
								nextChar();
							}
						}
						lis.Add(new LogoWord(sb.ToString(), usb.ToString()));
						starting = false;
						break;
					
				}
			}
		}
		
		
		
		
		
		
		/// <summary> Skip white space in the string
		/// </summary>
		private void  skipWhiteSpace()
		{
			while (WhiteSpace)
			{
				nextChar();
			}
		}
		
		
		/// <summary> Get next character in the string
		/// </summary>
		private void  nextChar()
		{
			_ch = (_index == _str.Length)?(char)0:_str[_index++]; //Birb-JLCA: added "(char)"
		}
		
		
		/// <summary> Append an escaped character to the stringbuffer
		/// *
		/// </summary>
		/// <param name="sb">the stringbuffer to add to
		/// 
		/// </param>
		private void  appendEscape(System.Text.StringBuilder sb)
		{
			if (_ch == 'n')
			{
				sb.Append('\n');
			}
			else if (_ch == 't')
			{
				sb.Append('\t');
			}
			else if (_ch == 'r')
			{
				sb.Append('\r');
			}
			else if (_ch == '0')
			{
				sb.Append('\x0000');
			}
			else
			{
				sb.Append(_ch);
			}
		}
	}
}