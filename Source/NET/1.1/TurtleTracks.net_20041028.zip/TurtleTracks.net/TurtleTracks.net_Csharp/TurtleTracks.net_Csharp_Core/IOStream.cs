/*
===============================================================================

FILE:  IOStream.java

PROJECT:

Turtle Tracks

CONTENTS:

Interface to logo stream objects

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> Generic stream using a BufferedReader and a BufferedWriter
	/// </summary>
	
	public class IOStream : IOBase
	{
		/// <summary> Is the stream open?
		/// *
		/// </summary>
		/// <returns> true iff can interact with stream
		/// 
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isOpen'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public bool Open
		{
			get
			{
				lock (this)
				{
					return (_writer != null || _reader != null);
				}
			}
			
		}
		/// <summary> Get a line from the stream
		/// *
		/// </summary>
		/// <returns> the string
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getLine'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public System.String Line
		{
			get
			{
				lock (this)
				{
					if (_reader == null)
					{
						if (_writer == null)
						{
							throw new LanguageException("Stream is closed");
						}
						else
						{
							//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
							throw new LanguageException("Can't read from " + _name.ToString());
						}
					}
					try
					{
						System.String str = _reader.ReadLine();
						if (str == null)
						{
							return "";
						}
						else
						{
							return str;
						}
					}
					catch (System.IO.IOException e)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException(e.ToString());
					}
				}
			}
			
		}
		/// <summary> Get a character from the stream
		/// *
		/// </summary>
		/// <returns> char the character
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getChar'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		virtual public char Char
		{
			get
			{
				lock (this)
				{
					if (_reader == null)
					{
						if (_writer == null)
						{
							throw new LanguageException("Stream is closed");
						}
						else
						{
							//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
							throw new LanguageException("Can't read from " + _name.ToString());
						}
					}
					try
					{
						return (char) (_reader.Read());
					}
					catch (System.IO.EndOfStreamException e)
					{
						return '\x0000';
					}
					catch (System.IO.IOException e)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException(e.ToString());
					}
				}
			}
			
		}
		
		private LogoObject _name;
		private System.IO.StreamReader _reader;
		private System.IO.StreamWriter _writer;
		
		private static LogoObject _kind;
		
		
		
		
		/// <summary> Constructor. Should always be followed by an open() call.
		/// </summary>
		public IOStream()
		{
			_name = LogoVoid.obj;
			_reader = null;
			_writer = null;
		}
		
		
		/// <summary> Create stream for reading
		/// *
		/// </summary>
		/// <param name="reader">stream to read
		/// 
		/// </param>
		public IOStream(System.IO.StreamReader reader)
		{
			_name = new LogoWord();
			_reader = reader;
			_writer = null;
		}
		
		
		/// <summary> Create stream for writing
		/// *
		/// </summary>
		/// <param name="writer">stream to write
		/// 
		/// </param>
		public IOStream(System.IO.StreamWriter writer)
		{
			_name = new LogoWord();
			_reader = null;
			_writer = writer;
		}
		
		
		/// <summary> Open stream for reading
		/// *
		/// </summary>
		/// <param name="name">name of stream
		/// </param>
		/// <param name="reader">stream to read
		/// 
		/// </param>
		public virtual void  open(LogoObject name, System.IO.StreamReader reader)
		{
			_name = name;
			_reader = reader;
			_writer = null;
		}
		
		
		/// <summary> Open stream for writing
		/// *
		/// </summary>
		/// <param name="name">name of stream
		/// </param>
		/// <param name="writer">stream to write
		/// 
		/// </param>
		public virtual void  open(LogoObject name, System.IO.StreamWriter writer)
		{
			_name = name;
			_reader = null;
			_writer = writer;
		}
		
		
		/// <summary> Open stream for reading and writing
		/// *
		/// </summary>
		/// <param name="name">name of stream
		/// </param>
		/// <param name="reader">stream to read
		/// </param>
		/// <param name="writer">stream to write
		/// 
		/// </param>
		public virtual void  open(LogoObject name, System.IO.StreamReader reader, System.IO.StreamWriter writer)
		{
			_name = name;
			_reader = reader;
			_writer = writer;
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'close'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Close the stream
		/// *
		/// </summary>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException can't close
		/// 
		/// </exception>
		public virtual void  close()
		{
			lock (this)
			{
				if (_writer == null && _reader == null)
				{
					throw new LanguageException("Stream already closed");
				}
				try
				{
					if (_writer != null)
					{
						_writer.Close();
					}
					if (_reader != null)
					{
						_reader.Close();
					}
				}
				catch (System.IO.IOException e)
				{
				}
				_writer = null;
				_reader = null;
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'name'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get the name of this object
		/// *
		/// </summary>
		/// <returns> the name as a LogoObject
		/// 
		/// </returns>
		public virtual LogoObject name()
		{
			lock (this)
			{
				return _name;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'kind'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get the kind of this object
		/// *
		/// </summary>
		/// <returns> the kind as a LogoObject
		/// 
		/// </returns>
		public virtual LogoObject kind()
		{
			lock (this)
			{
				return _kind;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eof'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Has the stream encountered EOF?
		/// *
		/// </summary>
		/// <returns> true iff eof encountered
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException stream closed
		/// 
		/// </exception>
		public virtual bool eof()
		{
			lock (this)
			{
				if (_reader == null)
				{
					if (_writer == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't read from " + _name.ToString());
					}
				}
				try
				{
					//UPGRADE_ISSUE: Method 'java.io.BufferedReader.mark' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javaioBufferedReadermark_int"'
					_reader.mark(2);
					int val = _reader.Read();
					if (val == - 1)
						return true;
					//UPGRADE_ISSUE: Method 'java.io.BufferedReader.reset' was not converted. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1000_javaioBufferedReaderreset"'
					_reader.reset();
				}
				catch (System.IO.IOException e)
				{
					return true;
				}
				return false;
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getAvailable'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Get all available data from stream
		/// *
		/// </summary>
		/// <param name="buf">buffer to read into
		/// *
		/// </param>
		/// <returns> how much data was actually read
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		public virtual int getAvailable(char[] buf)
		{
			lock (this)
			{
				if (_reader == null)
				{
					if (_writer == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't read from " + _name.ToString());
					}
				}
				try
				{
					int pos = 0;
					while (_reader.Peek() != -1 && pos < buf.Length)
					{
						buf[pos] = (char) (_reader.Read());
						pos++;
					}
					return pos;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'charAvail'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Character available on stream?
		/// *
		/// </summary>
		/// <returns> true iff available
		/// *
		/// </returns>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException read not allowed, or io closed
		/// 
		/// </exception>
		public virtual bool charAvail()
		{
			lock (this)
			{
				if (_reader == null)
				{
					if (_writer == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't read from " + _name.ToString());
					}
				}
				try
				{
					return _reader.Peek() != -1;
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a string to the stream
		/// *
		/// </summary>
		/// <param name="str">the string
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(System.String str)
		{
			lock (this)
			{
				if (_writer == null)
				{
					if (_reader == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't write to " + _name.ToString());
					}
				}
				try
				{
					_writer.Write(str);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'putLine'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a string to the stream, terminated with a newline
		/// *
		/// </summary>
		/// <param name="str">the string
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  putLine(System.String str)
		{
			lock (this)
			{
				if (_writer == null)
				{
					if (_reader == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't write to " + _name.ToString());
					}
				}
				try
				{
					_writer.Write(str);
					_writer.WriteLine();
					_writer.Flush();
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a char to the stream
		/// *
		/// </summary>
		/// <param name="c">the char
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(char c)
		{
			lock (this)
			{
				if (_writer == null)
				{
					if (_reader == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't write to " + _name.ToString());
					}
				}
				try
				{
					_writer.Write((System.Char) c);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'put'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Write a char array to the stream
		/// *
		/// </summary>
		/// <param name="buf">the buffer
		/// </param>
		/// <param name="num">number of characters
		/// *
		/// </param>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  put(char[] buf, int num)
		{
			lock (this)
			{
				if (_writer == null)
				{
					if (_reader == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't write to " + _name.ToString());
					}
				}
				try
				{
					//UPGRADE_NOTE: Exceptions thrown by the equivalent in .NET of method 'java.io.BufferedWriter.write' may be different. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1099"'
					_writer.Write(buf, 0, num);
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'flush'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Flush the stream
		/// *
		/// </summary>
		/// <exception cref=""> turtletracks_net.csharp.LanguageException write not allowed, or io closed
		/// 
		/// </exception>
		public virtual void  flush()
		{
			lock (this)
			{
				if (_writer == null)
				{
					if (_reader == null)
					{
						throw new LanguageException("Stream is closed");
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
						throw new LanguageException("Can't write to " + _name.ToString());
					}
				}
				try
				{
					_writer.Flush();
				}
				catch (System.IO.IOException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
					throw new LanguageException(e.ToString());
				}
			}
		}
		static IOStream()
		{
			{
				_kind = new LogoWord("UNKNOWN");
			}
		}
	}
}