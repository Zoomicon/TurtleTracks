/*
===============================================================================

FILE:  SymbolTable.java

PROJECT:

Turtle Tracks

CONTENTS:

A symbol table

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	/// <summary> A symbol table for a single scope
	/// </summary>
	
	public sealed class SymbolTable
	{
		/// <summary> Get a list of names from this level
		/// *
		/// </summary>
		/// <returns> the list
		/// 
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getNames'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		public LogoList Names //Birb-JLCA: removed "virtual"
		{
			get
			{
				lock (this)
				{
					System.Collections.ArrayList v = new System.Collections.ArrayList();
					System.Collections.IEnumerator enum_Renamed = _hash.Keys.GetEnumerator();
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1073"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1073"'
						v.Add(new LogoWord((CaselessString) (enum_Renamed.Current)));
					}
					
					return new LogoList(v);
				}
			}
			
		}
		/// <summary> Get an enumeration of names from this level
		/// *
		/// </summary>
		/// <returns> the enumeration
		/// 
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getEnumeratedNames'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		internal System.Collections.IEnumerator EnumeratedNames //Birb-JLCA: removed "virtual"
		{
			get
			{
				lock (this)
				{
					return _hash.Keys.GetEnumerator();
				}
			}
			
		}
		
		private System.Collections.Hashtable _hash;
		private SymbolTable _next;
		
		
		/// <summary> Construct an empty symbol table
		/// </summary>
		public SymbolTable()
		{
			_hash = new System.Collections.Hashtable(4);
			_next = null;
		}
		
		
		/// <summary> Push this table onto the given table, return new top
		/// </summary>
		internal SymbolTable pushOn(SymbolTable s)
		{
			_next = s;
			return this;
		}
		
		
		/// <summary> Return next table
		/// </summary>
		internal SymbolTable next()
		{
			return _next;
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'declare'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Declare symbol
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// </param>
		/// <param name="thread">the machine being run on
		/// 
		/// </param>
		public void  declare(CaselessString name, Machine mach)
		{
			lock (this)
			{
				if (!_hash.ContainsKey(name))
				{
					LogoObject obj = mach.resolveName(name);
					SupportClass.PutElement(_hash, name, (obj == null)?LogoVoid.obj:obj);
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'make'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Make symbol
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// </param>
		/// <param name="obj">the object to link to
		/// *
		/// </param>
		/// <returns> true iff symbol was declared.
		/// 
		/// </returns>
		public bool make(CaselessString name, LogoObject obj)
		{
			lock (this)
			{
				if (SupportClass.HashtableRemove(_hash, name) == null)
				{
					return false;
				}
				else
				{
					SupportClass.PutElement(_hash, name, obj);
					return true;
				}
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'makeForced'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Make symbol, forcing a declare if not declared
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// </param>
		/// <param name="obj">the object to link to
		/// 
		/// </param>
		public void  makeForced(CaselessString name, LogoObject obj)
		{
			lock (this)
			{
				SupportClass.HashtableRemove(_hash, name);
				SupportClass.PutElement(_hash, name, obj);
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'resolve'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Resolve symbol
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// *
		/// </param>
		/// <returns> the object, or null if not found
		/// 
		/// </returns>
		public LogoObject resolve(CaselessString name)
		{
			lock (this)
			{
				LogoObject obj = (LogoObject) (_hash[name]);
				return (obj == LogoVoid.obj)?null:obj;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'exists'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Symbol exists at this level
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// *
		/// </param>
		/// <returns> true iff symbol exists
		/// 
		/// </returns>
		public bool exists(CaselessString name)
		{
			lock (this)
			{
				return _hash.ContainsKey(name);
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'erase'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Delete symbol
		/// *
		/// </summary>
		/// <param name="name">symbol name
		/// *
		/// </param>
		/// <returns> true iff symbol found and deleted
		/// 
		/// </returns>
		public bool erase(CaselessString name)
		{
			lock (this)
			{
				return SupportClass.HashtableRemove(_hash, name) != null;
			}
		}
		
		
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eraseAll'. Lock expression was added. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1027"'
		/// <summary> Clear table level
		/// </summary>
		public void  eraseAll()
		{
			lock (this)
			{
				_hash.Clear();
			}
		}
		
		
		
		
	}
}