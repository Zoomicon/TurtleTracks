/*
===============================================================================

FILE:  CaselessString.java

PROJECT:

Turtle Tracks

CONTENTS:

String with caseless compare

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
namespace turtletracks_net.csharp
{
	using System;
	
	
	/// <summary> String with caseless compare
	/// <p>
	/// This class implements a subset of java.lang.string, in which the comparison
	/// functions, particularly equals(), can be set to ignore case.
	/// </summary>
	
	public sealed class CaselessString : System.ICloneable
	{
		/// <summary> Get case sensitivity
		/// *
		/// </summary>
		/// <returns> are compares case sensitive?
		/// 
		/// </returns>
		/// <summary> Set case sensitivity for all CaselessStrings
		/// *
		/// </summary>
		/// <param name="sensitivity">should compares be case sensitive?
		/// 
		/// </param>
		public static bool Sensitivity
		{
			get
			{
				return _caseSensitive;
			}
			
			set
			{
				_caseSensitive = value;
			}
			
		}
		
		// I really want to make this private static, but applets seem to
		// want access to it, presumably to construct the member when the class
		// is loaded.
		protected internal static bool _caseSensitive = false;
		
		private int _hashCode;
		
		/// <summary> The string represented by this CaselessString
		/// </summary>
		public System.String str;
		
		
		/// <summary> Constructs an empty caseless string
		/// </summary>
		public CaselessString()
		{
			str = new System.String("".ToCharArray());
			_hashCode = 0;
		}
		
		
		/// <summary> Constructs a caseless string whose value is given
		/// *
		/// </summary>
		/// <param name="s">the value
		/// 
		/// </param>
		public CaselessString(System.String s)
		{
			str = s;
			calcHashCode();
		}
		
		
		/// <summary> Constructs a caseless string whose value is a single character given
		/// *
		/// </summary>
		/// <param name="ch">the value
		/// 
		/// </param>
		public CaselessString(char ch)
		{
			char[] value_Renamed = new char[1];
			value_Renamed[0] = ch;
			str = new System.String(value_Renamed);
			calcHashCode();
		}
		
		
		/// <summary> Constructs a caseless string whose value is the character array given
		/// *
		/// </summary>
		/// <param name="value">the value
		/// 
		/// </param>
		public CaselessString(char[] value_Renamed)
		{
			str = new System.String(value_Renamed);
			calcHashCode();
		}
		
		
		/// <summary> Constructs a caseless string whose value is the StringBuffer given
		/// *
		/// </summary>
		/// <param name="buffer">the value
		/// 
		/// </param>
		public CaselessString(System.Text.StringBuilder buffer)
		{
			str = new System.String(buffer.ToString().ToCharArray());
			calcHashCode();
		}
		
		
		/// <summary> Precalculate hash code
		/// </summary>
		private void  calcHashCode()
		{
			_hashCode = str.ToUpper().GetHashCode();
		}
		
		
		/// <summary> Return hash code
		/// *
		/// </summary>
		/// <returns> hash code for the string
		/// 
		/// </returns>
		public override int GetHashCode()
		{
			return _hashCode;
		}
		
		
		//UPGRADE_TODO: The equivalent of method 'java.lang.Object.clone' is not an override method. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1143"'
		/// <summary> Clone this CaselessString
		/// *
		/// </summary>
		/// <returns> a copy of the object
		/// 
		/// </returns>
		public System.Object Clone()
		{
			return new CaselessString(str);
		}
		
		
		
		
		
		
		/// <summary> Extract string
		/// *
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		public override System.String ToString()
		{
			return str;
		}
		
		
		/// <summary> Special equals method
		/// *
		/// </summary>
		/// <param name="obj">the object to compare
		/// *
		/// </param>
		/// <returns> true if and only if the given object is equal in value to
		/// this object, subject to the current case sensitivity setting
		/// 
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
			return staticEquals(str, obj.ToString());
			/*		if (obj instanceof CaselessString)
			{
			if (_caseSensitive)
			return str.equals(((CaselessString)obj).str);
			else
			return str.equalsIgnoreCase(((CaselessString)obj).str);
			}
			else if (obj instanceof String)
			{
			if (_caseSensitive)
			return str.equals((String)obj);
			else
			return str.equalsIgnoreCase((String)obj);
			}
			else
			{
			return false;
			}*/
		}
		
		
		/// <summary> Special compare method
		/// *
		/// </summary>
		/// <param name="anotherString">the object to compare
		/// *
		/// </param>
		/// <returns> 0 if the given object's string representation is the same as
		/// this CaselessString. An integer >0 if the given object is lexically
		/// greater, or an integer <0 if the given object is lexically less.
		/// Comparison is subject to the current case sensitivity setting.
		/// 
		/// </returns>
		public int compareTo(System.Object anotherString)
		{
			//UPGRADE_TODO: The equivalent in .NET for method 'java.Object.toString' may return a different value. 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="jlca1043"'
			return staticCompare(str, anotherString.ToString());
		}
		
		
		/// <summary> Static compare method. Compares two given strings, subject to the
		/// current case sensitivity setting.
		/// *
		/// </summary>
		/// <param name="str1">the first string
		/// </param>
		/// <param name="str2">the second string
		/// *
		/// </param>
		/// <returns> 0 if the strings are equal, a negative integer if str1<str2,
		/// or a positive integer if str1>str2.
		/// 
		/// </returns>
		public static int staticCompare(System.String str1, System.String str2)
		{
			if (_caseSensitive)
			{
				return str1.CompareTo(str2);
			}
			else
			{
				char[] v1 = str1.ToCharArray();
				char[] v2 = str2.ToCharArray();
				int len1 = v1.Length;
				int len2 = v2.Length;
				int n = System.Math.Min(len1, len2);
				int i = 0;
				
				for (i = 0; i < n; i++)
				{
					char c1 = System.Char.ToUpper(v1[i]);
					char c2 = System.Char.ToUpper(v2[i]);
					if (c1 != c2)
					{
						return c1 - c2;
					}
				}
				return len1 - len2;
			}
		}
		
		
		/// <summary> Static eauzls method. Compares two given strings, subject to the current
		/// case sensitivity setting.
		/// *
		/// </summary>
		/// <param name="str1">the first string
		/// </param>
		/// <param name="str2">the second string
		/// *
		/// </param>
		/// <returns> true if and only if the two strings are equal
		/// 
		/// </returns>
		public static bool staticEquals(System.String str1, System.String str2)
		{
			if (_caseSensitive)
			{
				return str1.Equals(str2);
			}
			else
			{
				return str1.ToUpper().Equals(str2.ToUpper());
			}
		}
		
		
		/// <summary> Get "unparsed" form of this string
		/// *
		/// </summary>
		/// <returns> unparsed string
		/// 
		/// </returns>
		public System.String unparse()
		{
			return staticUnparse(str);
		}
		
		
		/// <summary> Get "unparsed" form of the given string
		/// *
		/// </summary>
		/// <param name="str">the string to unparse
		/// *
		/// </param>
		/// <returns> unparsed string
		/// 
		/// </returns>
		public static System.String staticUnparse(System.String str)
		{
			int i;
			
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			
			for (i = 0; i < str.Length; i++)
			{
				char ch = str[i];
				switch (ch)
				{
					
					case ' ': 
					case '[': 
					case ']': 
					case '|': 
					case ';': 
					case '\\': 
						sb.Append('\\').Append(ch);
						break;
					
					
					case '\t': 
						sb.Append('\\').Append('t');
						break;
					
					case '\r': 
						sb.Append('\\').Append('r');
						break;
					
					case '\n': 
						sb.Append('\\').Append('n');
						break;
					
					default: 
						sb.Append(ch);
						break;
					
				}
			}
			
			return sb.ToString();
		}
	}
}