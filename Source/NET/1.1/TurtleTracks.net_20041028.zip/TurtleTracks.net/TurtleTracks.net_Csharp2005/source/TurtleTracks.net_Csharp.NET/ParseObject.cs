/*
===============================================================================

FILE:  ParseObject.java

PROJECT:

Turtle Tracks

CONTENTS:

Node in a parse tree

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> General parsetree node</summary>
	
	public abstract class ParseObject : System.ICloneable
	{
		
		/// <summary> Clone the object
		/// 
		/// </summary>
		/// <returns> a clone of this object
		/// </returns>
        public abstract System.Object Clone(); //Birb-JLCA: was missing ending ";"
        /*{
		}*/ //Birb-JLCA
		
		
		/// <summary> Determine if another object is equal to this one
		/// 
		/// </summary>
		/// <param name="obj">what to compare with
		/// 
		/// </param>
		/// <returns> true iff equal
		/// </returns>
		abstract public  override bool Equals(System.Object obj);
		
		
		/// <summary> Evaluate this object in the given environment
		/// 
		/// </summary>
		/// <param name="interp">the environment
		/// 
		/// </param>
		/// <returns> the value
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.jsharp.ThrowException exception thrown
		/// </exception>
		internal abstract LogoObject evaluate(InterpEnviron interp);
		
		
		/// <summary> The name of the procedure
		/// 
		/// </summary>
		/// <returns> the name
		/// </returns>
		internal virtual System.String procName()
		{
			return new System.Text.StringBuilder().ToString();
		}
		//UPGRADE_NOTE: The following method implementation was automatically added to preserve functionality. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1306_3"'
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}
	}
}