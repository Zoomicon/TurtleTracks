/*
===============================================================================

FILE:  LogoObject.java

PROJECT:

Turtle Tracks

CONTENTS:

Standard logo object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Abstract Logo object. LogoList, LogoWord and LogoVoid extend this class.</summary>
	
	public abstract class LogoObject:ParseObject
	{
		
		/// <summary> Evaluate this object in the given environment
		/// 
		/// </summary>
		/// <param name="interp">the environment
		/// 
		/// </param>
		/// <returns> the value
		/// </returns>
		internal override LogoObject evaluate(InterpEnviron interp)
		{
			return this;
		}
		
		
		/// <summary> Write to a caseless string
		/// 
		/// </summary>
		/// <returns> the string
		/// </returns>
		public virtual CaselessString toCaselessString()
		{
			//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
			return new CaselessString(ToString());
		}
		
		
		/// <summary> Unparse object
		/// 
		/// </summary>
		/// <returns> the string
		/// </returns>
		public abstract System.String unparse();
		
		
		/// <summary> Returns a list that has been retokenized for running
		/// 
		/// </summary>
		/// <param name="mach">the machine to parse with
		/// 
		/// </param>
		/// <returns> the parse tree
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException not a runnable list
		/// </exception>
		public virtual ParseTree getRunnable(Machine mach)
		{
			throw new LanguageException("Runnable list expected");
		}
		
		
		/// <summary> Copy the first element of the list or first character of the word
		/// 
		/// </summary>
		/// <returns> an object containing first
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException object is an empty list or word
		/// </exception>
		public virtual LogoObject first()
		{
			throw new LanguageException("Object expected");
		}
		
		
		/// <summary> Copy the last element of the list or last character of the word
		/// 
		/// </summary>
		/// <returns> an object containing last
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException object is an empty list or word
		/// </exception>
		public virtual LogoObject last()
		{
			throw new LanguageException("Object expected");
		}
		
		
		/// <summary> Copy all parts except first
		/// 
		/// </summary>
		/// <returns> a new object containing butfirst
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException object is an empty list or word
		/// </exception>
		public virtual LogoObject butFirst()
		{
			throw new LanguageException("Object expected");
		}
		
		
		/// <summary> Copy all parts except last
		/// 
		/// </summary>
		/// <returns> a new object containing butfirst
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException object is an empty list or word
		/// </exception>
		public virtual LogoObject butLast()
		{
			throw new LanguageException("Object expected");
		}
		
		
		/// <summary> Turns this word into a number
		/// 
		/// </summary>
		/// <returns> the number value
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException bad number format or list given
		/// </exception>
		public virtual double toNumber()
		{
			throw new LanguageException("Number expected");
		}
		
		
		/// <summary> Turns this word into an integer
		/// 
		/// </summary>
		/// <returns> the number value
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException bad number format or list given
		/// </exception>
		public virtual int toInteger()
		{
			throw new LanguageException("Integer expected");
		}
		
		
		/// <summary> Turns this word into a boolean
		/// 
		/// </summary>
		/// <returns> the boolean value
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException bad boolean format or list given
		/// </exception>
		public virtual bool toBoolean()
		{
			throw new LanguageException("Boolean expression expected");
		}
		
		
		/// <summary> Returns length of the object or word
		/// 
		/// </summary>
		/// <returns> the length
		/// </returns>
		public abstract int length();
		
		
		/// <summary> Pick the index'th member of the list
		/// 
		/// </summary>
		/// <returns> the member
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException index out of bounds or empty object
		/// </exception>
		public virtual LogoObject pick(int index)
		{
			throw new LanguageException("Object expected");
		}
		
		
		/// <summary> Enumerates object as caseless strings
		/// 
		/// </summary>
		/// <returns> the enumerator
		/// </returns>
		internal virtual System.Collections.IEnumerator enumerateCaselessStrings()
		{
			return new LOCSEnumerator(this);
		}
		
		
		//UPGRADE_NOTE: Field 'EnclosingInstance' was added to class 'LOCSEnumerator' to access its enclosing instance. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1019_3"'
		/// <summary> LogoObject to CaselessString enumerator</summary>
		
		internal class LOCSEnumerator : System.Collections.IEnumerator
		{
			private void  InitBlock(LogoObject enclosingInstance)
			{
				this.enclosingInstance = enclosingInstance;
			}
			private System.Object tempAuxObj;
			public virtual bool MoveNext()
			{
				bool result = hasMoreElements();
				if (result)
				{
					tempAuxObj = nextElement();
				}
				return result;
			}
			public virtual void  Reset()
			{
				tempAuxObj = null;
			}
			public virtual System.Object Current
			{
				get
				{
					return tempAuxObj;
				}
				
			}
			private LogoObject enclosingInstance;
			public LogoObject Enclosing_Instance
			{
				get
				{
					return enclosingInstance;
				}
				
			}
			
			private int _index;
			
			
			/// <summary> Constructor</summary>
			internal LOCSEnumerator(LogoObject enclosingInstance)
			{
				InitBlock(enclosingInstance);
				if (Enclosing_Instance is LogoWord)
				{
					_index = - 1;
				}
				else if (Enclosing_Instance is LogoList)
				{
					_index = 0;
				}
				else
				{
					_index = - 2;
				}
			}
			
			
			/// <summary> Does it have more elements?</summary>
			//UPGRADE_NOTE: The equivalent of method 'java.util.Enumeration.hasMoreElements' is not an override method. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1143_3"'
			public virtual bool hasMoreElements()
			{
				if (_index == - 1)
				{
					return true;
				}
				else if (_index == - 2)
				{
					return false;
				}
				else
				{
					return Enclosing_Instance.length() > _index;
				}
			}
			
			
			/// <summary> Get next element
			/// 
			/// </summary>
			/// <exception cref=""> turtletracks_net.jsharp.NoSuchElementException no more elements
			/// </exception>
			//UPGRADE_NOTE: The equivalent of method 'java.util.Enumeration.nextElement' is not an override method. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1143_3"'
			public virtual System.Object nextElement()
			{
				if (_index == - 1)
				{
					_index = - 2;
					return Enclosing_Instance.toCaselessString();
				}
				else if (_index >= 0 && _index < Enclosing_Instance.length())
				{
					_index++;
					return ((LogoList) (Enclosing_Instance)).pickInPlace(_index - 1).toCaselessString();
				}
				else
				{
					throw new System.ArgumentOutOfRangeException("LOCSEnumerator");
				}
			}
		}
	}
}