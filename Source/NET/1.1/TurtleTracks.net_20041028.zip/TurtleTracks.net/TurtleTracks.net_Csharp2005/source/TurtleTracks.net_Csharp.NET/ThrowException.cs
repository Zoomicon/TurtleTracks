/*
===============================================================================

FILE:  ThrowException.java

PROJECT:

Turtle Tracks

CONTENTS:

Encountered command to throw

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Exception corresponding to a Logo exception</summary>
	
	[Serializable]
	public sealed class ThrowException:System.Exception
	{
		/// <summary> Gets the tag
		/// 
		/// </summary>
		/// <returns> the tag
		/// </returns>
		public CaselessString Tag
		{
			get
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				return new CaselessString(Message);
			}
			
		}
		/// <summary> Gets the output value
		/// 
		/// </summary>
		/// <returns> the object
		/// </returns>
		public LogoObject Obj
		{
			get
			{
				return _obj;
			}
			
		}
		
		private LogoObject _obj;
		
		
		/// <summary> Constructor with a tag and an output value
		/// 
		/// </summary>
		/// <param name="s">the tag
		/// </param>
		/// <param name="o">the output value
		/// </param>
		public ThrowException(System.String s, LogoObject o):base(s)
		{
			_obj = o;
		}
		
		
		/// <summary> Constructor with a tag and no output value
		/// 
		/// </summary>
		/// <param name="s">the tag
		/// </param>
		public ThrowException(System.String s):base(s)
		{
			_obj = LogoVoid.obj;
		}
		
		
		/// <summary> Changes to string
		/// 
		/// </summary>
		/// <returns> the string
		/// </returns>
		public override System.String ToString()
		{
			//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
			//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
			return "ThrowException: tag=" + Message + " obj=" + _obj.ToString();
		}
	}
}