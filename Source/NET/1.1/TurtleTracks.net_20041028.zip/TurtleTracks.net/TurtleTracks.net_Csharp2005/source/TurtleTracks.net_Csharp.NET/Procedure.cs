/*
===============================================================================

FILE:  Procedure.java

PROJECT:

Turtle Tracks

CONTENTS:

Logo procedure

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Procedure object</summary>
	
	public sealed class Procedure : System.ICloneable
	{
		/// <summary> Gets the procedure name
		/// 
		/// </summary>
		/// <returns> the name
		/// </returns>
		public CaselessString Name
		{
			get
			{
				return _name;
			}
			
		}
		/// <summary> Get parameter list
		/// 
		/// </summary>
		/// <returns> the list of parameter names
		/// </returns>
		public LogoList Params
		{
			get
			{
				return _params;
			}
			
		}
		/// <summary> Get header string
		/// 
		/// </summary>
		/// <returns> the header in the form "TO foo :param..."
		/// </returns>
		public System.String HeaderString
		{
			get
			{
				System.Text.StringBuilder sb;
				if (_isMacro)
				{
					sb = new System.Text.StringBuilder("TOMACRO ");
				}
				else
				{
					sb = new System.Text.StringBuilder("TO ");
				}
				SupportClass.Tokenizer tok = new SupportClass.Tokenizer(_params.toStringOpen());
				
				sb.Append(_name);
				
				while (tok.HasMoreTokens())
				{
					sb.Append(' ').Append(':').Append(tok.NextToken());
				}
				
				return sb.ToString();
			}
			
		}
		/// <summary> Get code list
		/// 
		/// </summary>
		/// <returns> a list containing the code
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException unable to tokenize
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getCode'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoList Code
		{
			get
			{
				lock (this)
				{
					if (_code == null)
					{
						System.Text.StringBuilder sb = new System.Text.StringBuilder();
						int i;
						for (i = 0; i < _codeStrs.Length; i++)
						{
							sb.Append(_codeStrs[i]).Append(Machine.LINE_SEPARATOR);
						}
						_code = new Tokenizer(_mach.TokenizerCommentFlags).tokenize(sb.ToString());
					}
					return _code;
				}
			}
			
		}
		/// <summary> Is this a macro?
		/// 
		/// </summary>
		/// <returns> isMacro
		/// </returns>
		public bool Macro
		{
			get
			{
				return _isMacro;
			}
			
		}
		
		private Machine _mach;
		private CaselessString _name;
		private System.String[] _codeStrs;
		private LogoList _params;
		private LogoList _code;
		private bool _isMacro;
		
		
		/// <summary> Construct a procedure with given strings (used by clone)</summary>
		private Procedure(Machine mach, CaselessString n, LogoList p, System.String[] cs, bool isMacro)
		{
			_mach = mach;
			_name = n;
			_params = p;
			_code = null;
			_codeStrs = cs;
			_isMacro = isMacro;
		}
		
		
		/// <summary> Construct a procedure with given strings (used by TO)
		/// 
		/// </summary>
		/// <param name="mach">the machine in use
		/// </param>
		/// <param name="n">name of procedure
		/// </param>
		/// <param name="p">param list
		/// </param>
		/// <param name="v">Vector of strings specifying the code
		/// </param>
		/// <param name="isMacro">is the procedure a macro
		/// </param>
		public Procedure(Machine mach, CaselessString n, LogoList p, System.Collections.ArrayList v, bool isMacro)
		{
			_mach = mach;
			_name = n;
			_params = p;
			_code = null;
			_codeStrs = new System.String[v.Count];
			for (int i = 0; i < _codeStrs.Length; i++)
			{
				_codeStrs[i] = ((System.String) (v[i]));
			}
			_isMacro = isMacro;
		}
		
		
		/// <summary> Generate a procedure given lists (used by DEFINE)
		/// 
		/// </summary>
		/// <param name="mach">the machine in use
		/// </param>
		/// <param name="n">name of procedure
		/// </param>
		/// <param name="p">param list
		/// </param>
		/// <param name="c">code list
		/// </param>
		/// <param name="isMacro">is the procedure a macro
		/// </param>
		public Procedure(Machine mach, CaselessString n, LogoList p, LogoList c, bool isMacro)
		{
			_mach = mach;
			_params = p;
			_code = c;
			_name = n;
			_codeStrs = new System.String[1];
			_codeStrs[0] = _code.toStringOpen();
			_isMacro = isMacro;
		}
		
		
		/// <summary> Clone the object
		/// 
		/// </summary>
		/// <returns> a clone of this object
		/// </returns>
        public System.Object Clone()/*:*/{ //Birb-JLCA, removed ":"
            return new Procedure(_mach, _name, _params, _codeStrs, _isMacro);
		}
		/*{ //Birb-JLCA
		}*/
		
		
		/// <summary> Determine if another object is equal to this one
		/// 
		/// </summary>
		/// <param name="obj">what to compare with
		/// 
		/// </param>
		/// <returns> true iff equal
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			if (obj is Procedure)
			{
				return ((Procedure) obj)._name.Equals(_name);
			}
			else if (obj is CaselessString || obj is System.String)
			{
				return (_name.Equals(obj));
			}
			else
			{
				return false;
			}
		}
		
		
		/// <summary> Sanity check parameter list
		/// 
		/// </summary>
		/// <param name="p">param list
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException bad symbol name
		/// </exception>
		public static void  checkParamNames(LogoList p)
		{
			LogoObject obj;
			int i;
			int j;
			
			for (i = 0; i < p.length(); i++)
			{
				obj = p.pickInPlace(i);
				
				if (!(obj is LogoWord))
				{
					throw new LanguageException("Parameter symbol names must be words");
				}
				for (j = i + 1; j < p.length(); j++)
				{
					if (obj.Equals(p.pickInPlace(j)))
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						throw new LanguageException("Duplicate parameter symbol name: " + obj);
					}
				}
			}
		}
		
		
		/// <summary> Convert the procedure into a string
		/// 
		/// </summary>
		/// <returns> the string
		/// </returns>
		public override System.String ToString()
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder(HeaderString);
			for (int i = 0; i < _codeStrs.Length; i++)
			{
				sb.Append(Machine.LINE_SEPARATOR).Append(_codeStrs[i]);
			}
			return sb.Append(Machine.LINE_SEPARATOR).Append("END").Append(Machine.LINE_SEPARATOR).ToString();
		}
		
		
		/// <summary> Write the procedure to the specified IOBase.
		/// 
		/// </summary>
		/// <param name="stream">the stream to write to
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException i/o error
		/// </exception>
		public void  writeToIO(IOBase stream)
		{
			stream.putLine(HeaderString);
			for (int i = 0; i < _codeStrs.Length; i++)
			{
				stream.putLine(_codeStrs[i]);
			}
			stream.putLine(ParseSpecial.strEND);
		}
		
		
		/// <summary> Get default number of arguments
		/// 
		/// </summary>
		/// <returns> number of arguments
		/// </returns>
		public int numArgs()
		{
			return _params.length();
		}
		
		
		/// <summary> Check procedure name, make sure it is okay
		/// 
		/// </summary>
		/// <param name="name">name to check
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException bad name
		/// </exception>
		public static void  checkName(System.String name)
		{
			if (name.Length == 0)
			{
				throw new LanguageException("Bad name: empty string");
			}
			try
			{
				/*[Birb: unused] double val =*/ System.Double.Parse(name);
				throw new LanguageException("Bad name: \"" + name + "\" looks like a number.");
			}
            catch (System.FormatException) //Birb: removed "e" to avoid compiler warning
            {
			}
		}
		//UPGRADE_NOTE: The following method implementation was automatically added to preserve functionality. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1306_3"'
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}
	}
}