/*
===============================================================================

FILE:  IOSocket.java

PROJECT:

Turtle Tracks

CONTENTS:

Socket stream object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Stream that reads from and writes to a socket</summary>
	
	public class IOSocket:IOStream
	{
		
		private System.Net.Sockets.TcpClient _theSocket;
		
		private static LogoObject _kind;
		
		
		/// <summary> Constructor
		/// 
		/// </summary>
		/// <param name="h">hostname
		/// </param>
		/// <param name="p">port number
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException can't open socket
		/// </exception>
		
		private MyTcpClient:TcpClient 
	    {
		 //...add code here to expose Port and LocalPort or Client
 
     	}       
        
        
        public IOSocket(System.String h, int p)
		{
			try
			{
				_theSocket = new System.Net.Sockets.TcpClient(h, p);
				LogoObject[] a = new LogoObject[3];
				//UPGRADE_ISSUE: Method 'java.net.Socket.getLocalPort' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetLocalPort_3"'
                a[0] = new LogoWord(((System.Net.IPEndPoint)_theSocket.Client.LocalEndPoint).Port); //Birb-JLCA: changed "_theSocket.getLocalPort()" to "((System.Net.IPEndPoint)_theSocket.Client.LocalEndPoint).Port"
                //UPGRADE_TODO: The equivalent in .NET for method 'java.net.InetAddress.getHostName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				//UPGRADE_ISSUE: Method 'java.net.Socket.getInetAddress' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetInetAddress_3"'
				a[1] = new LogoWord(System.Net.Dns.GetHostByAddress(_theSocket.getInetAddress().ToString()).HostName);
				//UPGRADE_ISSUE: Method 'java.net.Socket.getPort' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetPort_3"'
				a[2] = new LogoWord(_theSocket.getPort());
				//UPGRADE_TODO: The differences in the expected value  of parameters for constructor 'java.io.BufferedReader.BufferedReader'  may cause compilation errors.  'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1092_3"'
				//UPGRADE_WARNING: At least one expression was used more than once in the target code. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1181_3"'
				open(new LogoList(a), new System.IO.StreamReader(new System.IO.StreamReader(_theSocket.GetStream(), System.Text.Encoding.Default).BaseStream, new System.IO.StreamReader(_theSocket.GetStream(), System.Text.Encoding.Default).CurrentEncoding), new System.IO.StreamWriter(new System.IO.StreamWriter(_theSocket.GetStream(), System.Text.Encoding.Default).BaseStream, new System.IO.StreamWriter(_theSocket.GetStream(), System.Text.Encoding.Default).Encoding));
			}
			catch (System.IO.IOException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				throw new LanguageException("Couldn't open socket: " + e.Message);
			}
			catch (System.Security.SecurityException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				throw new LanguageException(e.ToString());
			}
		}
		
		
		/// <summary> Constructor
		/// 
		/// </summary>
		/// <param name="s">socket to use
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException unable to open socket
		/// </exception>
		public IOSocket(System.Net.Sockets.TcpClient s)
		{
			try
			{
				_theSocket = s;
				LogoObject[] a = new LogoObject[3];
				//UPGRADE_ISSUE: Method 'java.net.Socket.getLocalPort' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetLocalPort_3"'
				a[0] = new LogoWord(_theSocket.getLocalPort());
				//UPGRADE_TODO: The equivalent in .NET for method 'java.net.InetAddress.getHostName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				//UPGRADE_ISSUE: Method 'java.net.Socket.getInetAddress' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetInetAddress_3"'
				a[1] = new LogoWord(System.Net.Dns.GetHostByAddress(_theSocket.getInetAddress().ToString()).HostName);
				//UPGRADE_ISSUE: Method 'java.net.Socket.getPort' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javanetSocketgetPort_3"'
				a[2] = new LogoWord(_theSocket.getPort());
				//UPGRADE_TODO: The differences in the expected value  of parameters for constructor 'java.io.BufferedReader.BufferedReader'  may cause compilation errors.  'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1092_3"'
				//UPGRADE_WARNING: At least one expression was used more than once in the target code. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1181_3"'
				open(new LogoList(a), new System.IO.StreamReader(new System.IO.StreamReader(_theSocket.GetStream(), System.Text.Encoding.Default).BaseStream, new System.IO.StreamReader(_theSocket.GetStream(), System.Text.Encoding.Default).CurrentEncoding), new System.IO.StreamWriter(new System.IO.StreamWriter(_theSocket.GetStream(), System.Text.Encoding.Default).BaseStream, new System.IO.StreamWriter(_theSocket.GetStream(), System.Text.Encoding.Default).Encoding));
			}
			catch (System.IO.IOException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				throw new LanguageException("Couldn't open socket: " + e.Message);
			}
			catch (System.Security.SecurityException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				throw new LanguageException(e.ToString());
			}
		}
		
		
		/// <summary> Close the stream
		/// 
		/// </summary>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException can't close
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'close'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public override void  close()
		{
			lock (this)
			{
				base.close();
				try
				{
					_theSocket.Close();
				}
                catch (System.IO.IOException) //Birb: removed "e" to avoid compiler warning
                {
				}
				_theSocket = null;
			}
		}
		
		
		/// <summary> Get the kind of this object
		/// 
		/// </summary>
		/// <returns> the kind as a LogoObject
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'kind'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public override LogoObject kind()
		{
			lock (this)
			{
				return _kind;
			}
		}
		
		
		/// <summary> Write a string to the stream, terminated with a network newline.<br>
		/// Because Mac-style newlines (\r) are incompatible with network newlines (\r\n)
		/// 
		/// </summary>
		/// <param name="str">the string
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException write not allowed, or io closed
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'putLine'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public override void  putLine(System.String str)
		{
			lock (this)
			{
				put(str + "\r\n");
			}
		}
		static IOSocket()
		{
			{
				_kind = new LogoWord("SOCKET");
			}
		}
	}
}