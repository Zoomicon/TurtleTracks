/*
===============================================================================

FILE:  LanguageException.java

PROJECT:

Turtle Tracks

CONTENTS:

Miscellaneous language exception

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> General-purpose language exception. Represents an error condition. If not
	/// caught, it will cause the machine to report an error to the console.
	/// </summary>
	
	[Serializable]
	public sealed class LanguageException:System.Exception
	{
		/// <summary> Accessor for primitive name
		/// 
		/// </summary>
		/// <returns> the primitive which threw the exception
		/// </returns>
		public System.String PrimName
		{
			get
			{
				return _prim;
			}
			
		}
		/// <summary> Accessor for procedure name
		/// 
		/// </summary>
		/// <returns> the procedure which threw the exception
		/// </returns>
		public System.String ProcName
		{
			get
			{
				return _proc;
			}
			
		}
		/// <summary> Accessor for continue character
		/// 
		/// </summary>
		/// <returns> the continue prompt character
		/// </returns>
		public char ContChar
		{
			get
			{
				return _cont;
			}
			
		}
		
		private System.String _prim;
		private System.String _proc;
		private char _cont;
		
		
		/// <summary> Default constructor</summary>
		public LanguageException():base()
		{
			_prim = null;
			_proc = null;
			_cont = '\x0000';
		}
		
		
		/// <summary> Constructor with a string
		/// 
		/// </summary>
		/// <param name="s">detail string
		/// </param>
		public LanguageException(System.String s):base(s)
		{
			_prim = null;
			_proc = null;
			_cont = '\x0000';
		}
		
		
		/// <summary> Constructor with a string and a continue
		/// 
		/// </summary>
		/// <param name="s">detail string
		/// </param>
		/// <param name="cont">continue prompt character (for tokenizer errors)
		/// </param>
		internal LanguageException(System.String s, char cont):base(s)
		{
			_prim = null;
			_proc = null;
			_cont = cont;
		}
		
		
		/// <summary> Constructor with a string and a primitive name
		/// 
		/// </summary>
		/// <param name="s">detail string
		/// </param>
		/// <param name="primitive">which threw the exception
		/// </param>
		public LanguageException(System.String s, System.String prim):base(s)
		{
			_prim = prim;
			_proc = null;
			_cont = '\x0000';
		}
		
		
		/// <summary> Constructor with a string, a primitive name, and a procedure name
		/// 
		/// </summary>
		/// <param name="s">detail string
		/// </param>
		/// <param name="primitive">which threw the exception
		/// </param>
		/// <param name="procedure">which threw the exception
		/// </param>
		internal LanguageException(System.String s, System.String prim, System.String proc):base(s)
		{
			_prim = prim;
			_proc = proc;
			_cont = '\x0000';
		}
		
		
		/// <summary> Full constructor
		/// 
		/// </summary>
		/// <param name="s">detail string
		/// </param>
		/// <param name="primitive">which threw the exception
		/// </param>
		/// <param name="procedure">which threw the exception
		/// </param>
		/// <param name="cont">continue prompt character (for tokenizer errors)
		/// </param>
		internal LanguageException(System.String s, System.String prim, System.String proc, char cont):base(s)
		{
			_prim = prim;
			_proc = proc;
			_cont = cont;
		}
		
		
		/// <summary> Generate error message
		/// 
		/// </summary>
		/// <returns> a string representation of the error message
		/// </returns>
		public System.String generateMessage()
		{
			if (_proc != null && _prim != null)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				return Message + Machine.LINE_SEPARATOR + "... while executing " + _prim.ToUpper() + Machine.LINE_SEPARATOR + "... in procedure " + _proc.ToUpper();
			}
			else if (_prim != null)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				return Message + Machine.LINE_SEPARATOR + "... while executing " + _prim.ToUpper();
			}
			else if (_proc != null)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				return Message + Machine.LINE_SEPARATOR + "... in procedure " + _proc.ToUpper();
			}
			else
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				return Message;
			}
		}
	}
}