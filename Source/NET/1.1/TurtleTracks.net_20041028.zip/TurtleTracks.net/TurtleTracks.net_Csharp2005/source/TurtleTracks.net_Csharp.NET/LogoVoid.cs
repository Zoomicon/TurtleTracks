/*
===============================================================================

FILE:  LogoVoid.java

PROJECT:

Turtle Tracks

CONTENTS:

Void logo object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Void object. Returned from procedures with no return value.</summary>
	
	public class LogoVoid:LogoObject, System.ICloneable
	{
		
		/// <summary> The void object. All voids are references to this one object. 
		/// Thus, you can test for void by testing for equality with the
		/// LogoVoid.obj reference, which should be faster than doing a
		/// dynamic typecheck.
		/// </summary>
		//UPGRADE_NOTE: Final was removed from the declaration of 'obj '. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1003_3"'
		public static readonly LogoVoid obj = new LogoVoid();
		
		
		/// <summary> Constructor</summary>
		private LogoVoid()
		{
		}
		
		
		/// <summary> Normally, you should never attempt to clone a LogoVoid.
		/// This clone method actually does not clone the object, but instead
		/// returns another reference to the global LogoVoid.
		/// 
		/// </summary>
		/// <returns> a clone of this object
		/// </returns>
        public override System.Object Clone()/*:*/{ //Birb-JLCA, removed ":", added "override"
            return obj;
		}
		/*{
		}*/ //Birb-JLCA
		
		
		/// <summary> Determine if another object is equal to this one
		/// 
		/// </summary>
		/// <param name="obj">what to compare with
		/// 
		/// </param>
		/// <returns> true iff equal
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			return (obj is LogoVoid);
		}
		
		
		/// <summary> Write to a string (for state saving)
		/// 
		/// </summary>
		/// <returns> the string
		/// </returns>
		public override System.String ToString()
		{
			return new System.Text.StringBuilder().ToString();
		}
		
		
		/// <summary> Unparse void
		/// 
		/// </summary>
		/// <returns> the empty string
		/// </returns>
		public override System.String unparse()
		{
			return new System.Text.StringBuilder().ToString();
		}
		
		
		/// <summary> Returns length of the object (i.e. 0)
		/// 
		/// </summary>
		/// <returns> the length
		/// </returns>
		public override int length()
		{
			return 0;
		}
		//UPGRADE_NOTE: The following method implementation was automatically added to preserve functionality. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1306_3"'
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}
	}
}