/*
===============================================================================

FILE: InterpreterThread.java

PROJECT:

Turtle Tracks

CONTENTS:

Interpreter thread

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Interpreter thread</summary>
	
	public sealed class InterpreterThread:SupportClass.ThreadClass
	{
		/// <summary> Is thread loading?
		/// 
		/// </summary>
		/// <returns> true if the thread is currently loading an environment file
		/// </returns>
		public bool Loading
		{
			get
			{
				return (_savedins != null);
			}
			
		}
		
		private Machine _mach;
		private Console _console;
		
		private CaselessString _id;
		private IOBase _ins;
		private IOBase _outs;
		private CaselessString _insid;
		private CaselessString _outsid;
		private IOBase _savedins;
		private bool _isRootThread;
		private SymbolTable _symStack;
		private LogoList _toInterpret;
		private ParseTree _treeInterpret;
		private bool _isStopping;
		
		
		/// <summary> Constructs a new InterpreterThread
		/// 
		/// </summary>
		/// <param name="id">a unique id word for the thread
		/// </param>
		/// <param name="ll">list to interpret
		/// </param>
		/// <param name="isid">stream name for the input stream
		/// </param>
		/// <param name="is">the actual input stream
		/// </param>
		/// <param name="osid">stream name for the output stream
		/// </param>
		/// <param name="os">the actual output stream
		/// </param>
		/// <param name="syms">the toplevel SymbolTable to use
		/// </param>
		/// <param name="m">the machine in use
		/// </param>
		internal InterpreterThread(CaselessString id, LogoList ll, CaselessString isid, IOBase is_Renamed, CaselessString osid, IOBase os, SymbolTable syms, Machine m):base()
		{
			_toInterpret = ll;
			_treeInterpret = null;
			_id = id;
			_mach = m;
			_console = m.console();
			_insid = isid;
			_outsid = osid;
			_ins = is_Renamed;
			_outs = os;
			_symStack = syms;
			_isRootThread = id.Equals(Machine.MAIN_THREAD_NAME);
			_savedins = null;
			_isStopping = false;
		}
		
		
		/// <summary> Constructs a new InterpreterThread
		/// 
		/// </summary>
		/// <param name="id">a unique id word for the thread
		/// </param>
		/// <param name="pt">ParseTree to interpret
		/// </param>
		/// <param name="isid">stream name for the input stream
		/// </param>
		/// <param name="is">the actual input stream
		/// </param>
		/// <param name="osid">stream name for the output stream
		/// </param>
		/// <param name="os">the actual output stream
		/// </param>
		/// <param name="syms">the toplevel SymbolTable to use
		/// </param>
		/// <param name="m">the machine in use
		/// </param>
		internal InterpreterThread(CaselessString id, ParseTree pt, CaselessString isid, IOBase is_Renamed, CaselessString osid, IOBase os, SymbolTable syms, Machine m):base()
		{
			_toInterpret = null;
			_treeInterpret = pt;
			_id = id;
			_mach = m;
			_console = m.console();
			_insid = isid;
			_outsid = osid;
			_ins = is_Renamed;
			_outs = os;
			_symStack = syms;
			_isRootThread = id.Equals(Machine.MAIN_THREAD_NAME);
			_savedins = null;
			_isStopping = false;
		}
		
		
		/// <summary> Constructs a new InterpreterThread for use by a console to do internal
		/// tasks such as loading environment files in response to menu commands.
		/// 
		/// </summary>
		/// <param name="m">the Machine in use
		/// </param>
		/// <param name="is">the input stream to interpret
		/// </param>
		public InterpreterThread(Machine m, IOBase is_Renamed):base()
		{
			_toInterpret = null;
			_mach = m;
			_console = m.console();
			_id = new CaselessString(turtletracks_net.jsharp.Machine.PRIVATE_NAME);
			_insid = new CaselessString(turtletracks_net.jsharp.Machine.PRIVATE_NAME);
			_outsid = new CaselessString(turtletracks_net.jsharp.Machine.PRIVATE_NAME);
			_ins = is_Renamed;
			_outs = _mach.console();
			_symStack = new SymbolTable();
			_isRootThread = true;
			_savedins = null;
			_isStopping = false;
		}
		
		
		/// <summary> Is thread stopping?
		/// 
		/// </summary>
		/// <returns> true if the thread is stopping
		/// </returns>
		public bool stopping()
		{
			return _isStopping;
		}
		
		
		/// <summary> Signal thread to stop</summary>
		public void  signalStop()
		{
			_isStopping = true;
		}
		
		
		/// <summary> Accessor for machine
		/// 
		/// </summary>
		/// <returns> the Machine running this thread
		/// </returns>
		public Machine mach()
		{
			return _mach;
		}
		
		
		/// <summary> Accessor for threadid
		/// 
		/// </summary>
		/// <returns> the thread ID
		/// </returns>
		public CaselessString threadID()
		{
			return _id;
		}
		
		
		/// <summary> Accessor for inStream
		/// 
		/// </summary>
		/// <returns> the current input stream in use by this thread
		/// </returns>
		public IOBase inStream()
		{
			return _ins;
		}
		
		
		/// <summary> Accessor for inStreamID
		/// 
		/// </summary>
		/// <returns> the id of the current input stream in use by this thread
		/// </returns>
		public CaselessString inStreamID()
		{
			return _insid;
		}
		
		
		/// <summary> Accessor for outStream
		/// 
		/// </summary>
		/// <returns> the current output stream in use by this thread
		/// </returns>
		public IOBase outStream()
		{
			return _outs;
		}
		
		
		/// <summary> Accessor for outStreamID
		/// 
		/// </summary>
		/// <returns> the id of the current output stream in use by this thread
		/// </returns>
		public CaselessString outStreamID()
		{
			return _outsid;
		}
		
		
		/// <summary> Mutator for inStream
		/// 
		/// </summary>
		/// <param name="isid">new input stream ID
		/// </param>
		/// <param name="is">new input stream
		/// </param>
		public void  setInStream(CaselessString isid, IOBase is_Renamed)
		{
			_insid = isid;
			_ins = is_Renamed;
			if (_isRootThread && _toInterpret != null)
			{
				_mach.setInStream(isid, is_Renamed);
			}
		}
		
		
		/// <summary> Mutator for outStream
		/// 
		/// </summary>
		/// <param name="osid">new output stream ID
		/// </param>
		/// <param name="os">new output stream
		/// </param>
		public void  setOutStream(CaselessString osid, IOBase os)
		{
			_outsid = osid;
			_outs = os;
			if (_isRootThread && _toInterpret != null)
			{
				_mach.setOutStream(osid, os);
			}
		}
		
		
		/// <summary> Starts loading. Used by the Machine to signal starting to load an environment
		/// file. Should normally not be called any other time
		/// 
		/// </summary>
		/// <param name="is">stream to read
		/// </param>
		public void  startLoading(IOBase is_Renamed)
		{
			_savedins = _ins;
			_ins = is_Renamed;
		}
		
		
		/// <summary> Ends loading. Used by the Machine to signal finishing load of an environment
		/// file. Should normally not be called any other time
		/// </summary>
		public void  endLoading()
		{
			_ins = _savedins;
			_savedins = null;
		}
		
		
		/// <summary> Enters a procedure in this thread
		/// 
		/// </summary>
		/// <param name="level">local symbol table
		/// </param>
		public void  enterProcedure(SymbolTable level)
		{
			_symStack = level.pushOn(_symStack);
		}
		
		
		/// <summary> Exits a procedure in this thread</summary>
		public void  exitProcedure()
		{
			_symStack = _symStack.next();
		}
		
		
		/// <summary> Declares a local variable
		/// 
		/// </summary>
		/// <param name="name">the name for the new variable
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException not in a procedure
		/// </exception>
		public void  localName(CaselessString name)
		{
			_symStack.declare(name, _mach);
		}
		
		
		/// <summary> Make a variable. If not declared locally, delegates to global symbol table.
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// </param>
		/// <param name="obj">value of the variable
		/// </param>
		public void  makeName(CaselessString name, LogoObject obj)
		{
			for (SymbolTable st = _symStack; st != null; st = st.next())
			{
				if (st.make(name, obj))
				{
					return ;
				}
			}
			_mach.makeName(name, obj);
		}
		
		
		/// <summary> Get value of a variable. If no local exists, delegates to global symbol table
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// 
		/// </param>
		/// <returns> the resolved symbol, or null if not found
		/// </returns>
		public LogoObject resolveName(CaselessString name)
		{
			for (SymbolTable st = _symStack; st != null; st = st.next())
			{
				LogoObject obj = st.resolve(name);
				if (obj != null)
				{
					return obj;
				}
			}
			return _mach.resolveName(name);
		}
		
		
		/// <summary> Erase a variable in all scopes
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// </param>
		public void  eraseName(CaselessString name)
		{
			for (SymbolTable st = _symStack; st != null; st = st.next())
			{
				st.erase(name);
			}
			_mach.eraseName(name);
		}
		
		
		/// <summary> Run method of this thread. Interprets the LogoList or ParseTree given
		/// to the thread.
		/// </summary>
		override public void  Run()
		{
			try
			{
				LogoObject ret = LogoVoid.obj;
				try
				{
					if (_toInterpret == null && _treeInterpret == null)
					{
						_mach.executeStream(_ins, this);
					}
					else
					{
						if (_treeInterpret == null)
						{
							_treeInterpret = _toInterpret.getRunnable(_mach);
						}
						ret = _treeInterpret.execute(new InterpEnviron(this));
					}
				}
				catch (ThrowException e)
				{
					CaselessString tag = e.Tag;
					if (tag.Equals("TOPLEVEL"))
					{
						_mach.terminateAllThreads();
					}
					else if (tag.Equals("GOODBYE"))
					{
						_mach.terminateAllThreads();
						_console.goodbye();
					}
					else if (tag.Equals("STOP"))
					{
						throw new LanguageException("Can use STOP or OUTPUT only inside a procedure");
					}
					else if (tag.Equals("STOPTHREAD") || tag.Equals(".SUDDENSTOPTHREAD"))
					{
					}
					else
					{
						_console.putLine("Uncaught: " + tag);
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						_console.putLine("... with value " + e.Obj.ToString());
						if (!_isRootThread)
						{
							_console.putLine("... in thread " + _id.str);
						}
						_mach.terminateAllThreads();
					}
				}
				if (!_mach.AutoIgnore && ret != LogoVoid.obj)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					throw new LanguageException("You don't say what to do with " + ret);
				}
			}
			catch (LanguageException e)
			{
				_console.putLine(e.generateMessage());
				if (!_isRootThread)
				{
					_console.putLine("... in thread " + _id.str);
				}
				_mach.terminateAllThreads();
			}
			//UPGRADE_NOTE: Exception 'java.lang.Throwable' was converted to 'System.Exception' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
			catch (System.Exception e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				_console.putLine(e.ToString());
				if (!_isRootThread)
				{
					_console.putLine("... in thread " + _id.str);
				}
                SupportClass.WriteStackTrace(e, System.Console.Error); //Birb-JLCA: replaced "Console" with "System.Console"
                _mach.terminateAllThreads();
			}
			finally
			{
				_mach.threadEnding(_id);
			}
		}
	}
}