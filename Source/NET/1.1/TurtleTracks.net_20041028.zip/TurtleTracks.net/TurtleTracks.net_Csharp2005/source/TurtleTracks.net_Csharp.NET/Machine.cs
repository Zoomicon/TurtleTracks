/*
===============================================================================

FILE:  Machine.java

PROJECT:

Turtle Tracks

CONTENTS:

Virtual machine object

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Logo runtime machine. Controls the current state of the runtime system.
	/// All Logo interpretation is done relative to a Machine.
	/// </summary>
	
	public sealed class Machine
	{
		/// <summary> Get the clock value. This is a global clock incremented whenever lists
		/// require reparsing.
		/// 
		/// </summary>
		/// <returns> the clock value
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getClock'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		internal int Clock
		{
			get
			{
				lock (this)
				{
					return _clock;
				}
			}
			
		}
		/// <summary> Set hash comments on or off
		/// 
		/// </summary>
		/// <param name="onoroff">hash comments on or off
		/// </param>
		public bool HashComments
		{
			set
			{
				_hashComments = value;
			}
			
		}
		/// <summary> Accessor for hash comments setting
		/// 
		/// </summary>
		/// <returns> flags to give to tokenizer
		/// </returns>
		public int TokenizerCommentFlags
		{
			get
			{
				if (_hashComments)
				{
					return Tokenizer.HONOR_COMMENTS | Tokenizer.HASH_COMMENT;
				}
				else
				{
					return Tokenizer.HONOR_COMMENTS;
				}
			}
			
		}
		/// <summary> Is overriding of primitive names allowed?
		/// 
		/// </summary>
		/// <returns> true if overriding is allowed
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isOverridePrimitives'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public bool OverridePrimitives
		{
			get
			{
				lock (this)
				{
					return _overridePrimitive;
				}
			}
			
		}
		/// <summary> Is auto-ignore activated
		/// 
		/// </summary>
		/// <returns> true if auto-ignore is active
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isAutoIgnore'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public bool AutoIgnore
		{
			get
			{
				lock (this)
				{
					return _autoIgnore;
				}
			}
			
		}
		/// <summary> Get LogoList of defined procedure names
		/// 
		/// </summary>
		/// <returns> the procedure list
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getProcList'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoList ProcList
		{
			get
			{
				lock (this)
				{
					System.Collections.ArrayList v = System.Collections.ArrayList.Synchronized(new System.Collections.ArrayList(10));
					System.Collections.IEnumerator enum_Renamed = _procs.Keys.GetEnumerator();
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						v.Add(new LogoWord((CaselessString) (enum_Renamed.Current)));
					}
					
					return new LogoList(v);
				}
			}
			
		}
		/// <summary> Get LogoList of names
		/// 
		/// </summary>
		/// <returns> the name list
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getNameList'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoObject NameList
		{
			get
			{
				lock (this)
				{
					return _syms.Names;
				}
			}
			
		}
		/// <summary> Get list of property list names
		/// 
		/// </summary>
		/// <returns> LogoList of list names
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getPLists'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoList PLists
		{
			get
			{
				lock (this)
				{
					System.Collections.ArrayList v = System.Collections.ArrayList.Synchronized(new System.Collections.ArrayList(10));
					System.Collections.IEnumerator enum_Renamed = _proplists.Keys.GetEnumerator();
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						v.Add(new LogoWord((CaselessString) (enum_Renamed.Current)));
					}
					
					return new LogoList(v);
				}
			}
			
		}
		/// <summary> Get LogoList of fileids
		/// 
		/// </summary>
		/// <returns> the procedure list
		/// </returns>
		public LogoList FileidList
		{
			get
			{
				System.Collections.ArrayList v = System.Collections.ArrayList.Synchronized(new System.Collections.ArrayList(10));
				
				lock (_fileids.SyncRoot)
				{
					System.Collections.IEnumerator enum_Renamed = _fileids.Keys.GetEnumerator();
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						v.Add(new LogoWord((CaselessString) (enum_Renamed.Current)));
					}
				}
				
				return new LogoList(v);
			}
			
		}
		/// <summary> Get new unique integer
		/// 
		/// </summary>
		/// <returns> the unique number
		/// </returns>
		public int UniqueNum
		{
			get
			{
				lock (_uniqueNumLock)
				{
					_uniqueNum++;
					return _uniqueNum;
				}
			}
			
		}
		
		/// <summary> The name of the console stream</summary>
		public const System.String CONSOLE_STREAM_NAME = ".CONSOLE";
		
		/// <summary> The name of the main thread</summary>
		public const System.String MAIN_THREAD_NAME = ".MAIN";
		
		/// <summary> The name of a private thread for use by loading, etc.</summary>
		public const System.String PRIVATE_NAME = ".PRIVATE";
		
		/// <summary> The name of the system property list</summary>
		public const System.String LOGO_PROPERTYLIST_NAME = ".SYSTEM";
		
		/// <summary> The current version of Turtle Tracks</summary>
		public const System.String TURTLETRACKS_VERSION = "1.0";
		
		/// <summary> The value of the system property "line.separator"</summary>
		//UPGRADE_NOTE: Final was removed from the declaration of 'LINE_SEPARATOR '. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1003_3"'
		public static readonly System.String LINE_SEPARATOR = System.Environment.NewLine;
		
		
		private System.Collections.ArrayList _primitiveGroups;
		
		private SymbolTable _syms;
		private System.Collections.Hashtable _procs;
		private System.Collections.Hashtable _fileids;
		private System.Collections.Hashtable _proplists;
		
		private System.Collections.Hashtable _data;
		
		private System.Collections.Hashtable _threads;
		private int _suspended;
		private System.Object _suspendedLock;
		
		private System.Random _random;
		private int _uniqueNum;
		private System.Object _uniqueNumLock;
		private int _clock;
		
		private IOBase _instream;
		private CaselessString _instreamID;
		private IOBase _outstream;
		private CaselessString _outstreamID;
		
		private Console _console;
		
		private bool _hashComments;
		private bool _overridePrimitive;
		private bool _autoIgnore;
		
		
		/// <summary> Create a new virtual machine. Note that the console and primitivegroups
		/// should be instantiated first, then passed to this constructor. After
		/// instantiating the Machine, you must call the setup() method to set up
		/// the console and primitivegroups.
		/// 
		/// </summary>
		/// <param name="ci">the console to use
		/// </param>
		/// <param name="pg">the primitive groups to use
		/// </param>
		public Machine(Console ci, PrimitiveGroup[] pg)
		{
			_syms = new SymbolTable();
			_procs = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
			_fileids = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
			_proplists = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
			
			_data = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
			
			_threads = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
			_suspended = 0;
			_suspendedLock = new System.Object();
			
			_uniqueNum = 0;
			_uniqueNumLock = new System.Object();
			//UPGRADE_TODO: The differences in the expected value  of parameters for constructor 'java.util.Random.Random'  may cause compilation errors.  'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1092_3"'
			_random = new System.Random((System.Int32) 0);
			
			_console = ci;
			
			_primitiveGroups = System.Collections.ArrayList.Synchronized(new System.Collections.ArrayList(pg.Length));
			for (int i = 0; i < pg.Length; i++)
			{
				_primitiveGroups.Add(pg[i]);
			}
			
			_instream = _console;
			_outstream = _console;
			_instreamID = null;
			_outstreamID = null;
			
			_clock = 0;
			
			_hashComments = false;
			_overridePrimitive = false;
			_autoIgnore = false;
		}
		
		
		/// <summary> Prepare environment by calling all the appropriate setup methods of the
		/// console and primitivegroups. This must be called before the machine can
		/// be invoked in any other way.
		/// 
		/// </summary>
		/// <exception cref=""> turtletracks_net.jsharp.SetupException The console or one of the
		/// PrimitiveGroups failed to initialize.
		/// </exception>
		public void  setup()
		{
			_console.Machine = this;
			_console.setup();
			_console.putStatusMessage("Turtle Tracks runtime system v1.0");
			for (int i = 0; i < _primitiveGroups.Count; i++)
			{
				((PrimitiveGroup) (_primitiveGroups[i])).setup(this, _console);
			}
		}
		
		
		/// <summary> Tear down environment. This should be called after the machine shuts down.
		/// It informs the console and all primitive groups to clean up.
		/// </summary>
		public void  cleanup()
		{
			for (int i = 0; i < _primitiveGroups.Count; i++)
			{
				((PrimitiveGroup) (_primitiveGroups[i])).exiting();
			}
			_console.exiting();
		}
		
		
		/// <summary> Get console
		/// 
		/// </summary>
		/// <returns> the console
		/// </returns>
		public Console console()
		{
			return _console;
		}
		
		
		/// <summary> Load primitive group and sets it up given a class name. Does nothing if a
		/// PrimitiveGroup with the same class name is already loaded in this machine.
		/// 
		/// </summary>
		/// <param name="classname">the name of the Java class to load.
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException couldn't load the primitive group.
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'loadPrimitives'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  loadPrimitives(System.String classname)
		{
			lock (this)
			{
				try
				{
					int i;
					for (i = 0; i < _primitiveGroups.Count; i++)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Class.getName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						if (_primitiveGroups[i].GetType().FullName.Equals(classname))
						{
							return ;
						}
					}
					//UPGRADE_TODO: The differences in the format  of parameters for method 'java.lang.Class.forName'  may cause compilation errors.  'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1092_3"'
					System.Type theClass = System.Type.GetType(classname);
					//UPGRADE_TODO: Method 'java.lang.Class.newInstance' was converted to 'System.Activator.CreateInstance' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javalangClassnewInstance_3"'
					PrimitiveGroup pg = (PrimitiveGroup) (System.Activator.CreateInstance(theClass));
					try
					{
						pg.setup(this, _console);
					}
                    catch (SetupException /*e*/) //Birb: removed "e" to avoid compiler warning
                    {
						throw new LanguageException("Primitive group " + classname + " refused to load.");
					}
					_primitiveGroups.Add(pg);
				}
				//UPGRADE_NOTE: Exception 'java.lang.ClassNotFoundException' was converted to 'System.Exception' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
                catch (System.TypeLoadException /*e*/) //Birb-JLCA: using "TypeLoadException" instead of "System.Exception"  //Birb: removed "e" to avoid compiler warning
                {
					throw new LanguageException("Class " + classname + " not found.");
				}
                catch (System.InvalidCastException /*e*/) //Birb: removed "e" to avoid compiler warning
                {
					throw new LanguageException("Class " + classname + " isn't a PrimitiveGroup.");
				}
				//UPGRADE_NOTE: Exception 'java.lang.InstantiationException' was converted to 'System.Exception' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
                catch (System.Reflection.TargetInvocationException /*e*/) //Birb-JLCA: using "TargetInvocationException" instead of "System.Exception"  //Birb: removed "e" to avoid compiler warning
                {
					throw new LanguageException("Class " + classname + " couldn't be instantiated.");
				}
                catch (System.UnauthorizedAccessException /*e*/) //Birb: removed "e" to avoid compiler warning
                {
					throw new LanguageException("Class " + classname + " not accessible.");
				}
				_clock++;
			}
		}
		
		
		/// <summary> Load primitive group and sets it up. The given PrimitiveGroup should be
		/// constructed, but should not already have had its setup method called--
		/// loadPrimitives will call the setup method. Does nothing if a PrimitiveGroup
		/// with the same class name is already loaded in this machine.
		/// 
		/// </summary>
		/// <param name="pg">the PrimitiveGroup object
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException couldn't setup the primitive group.
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'loadPrimitives'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  loadPrimitives(PrimitiveGroup pg)
		{
			lock (this)
			{
				System.String className = pg.GetType().FullName;
				for (int i = 0; i < _primitiveGroups.Count; i++)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Class.getName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					if (_primitiveGroups[i].GetType().FullName.Equals(className))
					{
						return ;
					}
				}
				try
				{
					pg.setup(this, _console);
				}
                catch (SetupException /*e*/) //Birb: removed "e" to avoid compiler warning
                {
					throw new LanguageException("Primitive group " + className + " refused to load.");
				}
				_primitiveGroups.Add(pg);
				_clock++;
			}
		}
		
		
		/// <summary> Clean up and unload primitive group. If no PrimitiveGroup with the given
		/// class name is loaded in this machine, unloadPrimitives does nothing.
		/// 
		/// </summary>
		/// <param name="classname">the name of the Java class to unload.
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'unloadPrimitives'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  unloadPrimitives(System.String classname)
		{
			lock (this)
			{
				for (int i = 0; i < _primitiveGroups.Count; i++)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Class.getName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					if (_primitiveGroups[i].GetType().FullName.Equals(classname))
					{
						((PrimitiveGroup) (_primitiveGroups[i])).exiting();
						_primitiveGroups.RemoveAt(i);
						_clock++;
						return ;
					}
				}
			}
		}
		
		
		/// <summary> Clean up and unload the given primitive group. If the PrimitiveGroup
		/// is not loaded into this machine, unloadPrimitives does nothing.
		/// 
		/// </summary>
		/// <param name="pg">the PrimitiveGroup to unload
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'unloadPrimitives'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  unloadPrimitives(PrimitiveGroup pg)
		{
			lock (this)
			{
				for (int i = 0; i < _primitiveGroups.Count; i++)
				{
					if (_primitiveGroups[i] == pg)
					{
						pg.exiting();
						_primitiveGroups.RemoveAt(i);
						_clock++;
						return ;
					}
				}
			}
		}
		
		
		/// <summary> Get primitive group given the class name.
		/// 
		/// </summary>
		/// <param name="classname">the name of the Java class to look for.
		/// 
		/// </param>
		/// <returns> the PrimitiveGroup, or null if not found.
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getPrimitiveGroup'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public PrimitiveGroup getPrimitiveGroup(System.String classname)
		{
			lock (this)
			{
				for (int i = 0; i < _primitiveGroups.Count; i++)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Class.getName' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					if (_primitiveGroups[i].GetType().FullName.Equals(classname))
					{
						return (PrimitiveGroup) (_primitiveGroups[i]);
					}
				}
				return null;
			}
		}
		
		
		/// <summary> Search primitive groups for primitive
		/// 
		/// </summary>
		/// <param name="name">the name of the primitive to find
		/// 
		/// </param>
		/// <returns> a PrimitiveSpec describing the primitive definition, or null
		/// if the primitive is not found.
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'findPrimitive'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public PrimitiveSpec findPrimitive(CaselessString name)
		{
			lock (this)
			{
				int i;
				//Birb: unused// Method method;
				for (i = _primitiveGroups.Count - 1; i >= 0; i--)
				{
					PrimitiveSpec spec = ((PrimitiveGroup) (_primitiveGroups[i])).getPrimitiveMethod(name);
					if (spec != null)
					{
						return spec;
					}
				}
				return null;
			}
		}
		
		
		/// <summary> Spawn new thread given a LogoList
		/// 
		/// </summary>
		/// <param name="id">the thread id
		/// </param>
		/// <param name="ll">the list to interpret
		/// </param>
		/// <param name="isid">the input stream id
		/// </param>
		/// <param name="is">the input stream itself
		/// </param>
		/// <param name="osid">the output stream id
		/// </param>
		/// <param name="os">the output stream itself
		/// </param>
		/// <param name="syms">the toplevel local scope SymbolTable
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException duplicate thread ID
		/// </exception>
		public void  spawnThread(CaselessString id, LogoList ll, CaselessString isid, IOBase is_Renamed, CaselessString osid, IOBase os, SymbolTable syms)
		{
			lock (_threads.SyncRoot)
			{
				// Don't allow a stopped thread to spawn other threads
				SupportClass.ThreadClass t = SupportClass.ThreadClass.Current();
				if (t is InterpreterThread)
				{
					if (((InterpreterThread) t).stopping())
					{
						return ;
					}
				}
				if (_threads[id] != null)
				{
					throw new LanguageException("Duplicate thread ID");
				}
				InterpreterThread thread = new InterpreterThread(id, ll, isid, is_Renamed, osid, os, syms, this);
				_threads[id] = thread;
				thread.Start();
			}
		}
		
		
		/// <summary> Spawn new thread given a ParseTree
		/// 
		/// </summary>
		/// <param name="id">the thread id
		/// </param>
		/// <param name="pt">the ParseTree to interpret
		/// </param>
		/// <param name="isid">the input stream id
		/// </param>
		/// <param name="is">the input stream itself
		/// </param>
		/// <param name="osid">the output stream id
		/// </param>
		/// <param name="os">the output stream itself
		/// </param>
		/// <param name="syms">the toplevel local scope SymbolTable
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException duplicate thread ID
		/// </exception>
		public void  spawnThread(CaselessString id, ParseTree pt, CaselessString isid, IOBase is_Renamed, CaselessString osid, IOBase os, SymbolTable syms)
		{
			lock (_threads.SyncRoot)
			{
				// Don't allow a stopped thread to spawn other threads
				SupportClass.ThreadClass t = SupportClass.ThreadClass.Current();
				if (t is InterpreterThread)
				{
					if (((InterpreterThread) t).stopping())
					{
						return ;
					}
				}
				if (_threads[id] != null)
				{
					throw new LanguageException("Duplicate thread ID");
				}
				InterpreterThread thread = new InterpreterThread(id, pt, isid, is_Renamed, osid, os, syms, this);
				_threads[id] = thread;
				thread.Start();
			}
		}
		
		
		/// <summary> Spawn main thread
		/// 
		/// </summary>
		/// <param name="ll">the list to interpret
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException Already a main thread running
		/// </exception>
		public void  spawnMainThread(LogoList ll)
		{
			spawnThread(new CaselessString(MAIN_THREAD_NAME), ll, _instreamID, _instream, _outstreamID, _outstream, new SymbolTable());
		}
		
		
		/// <summary> Remove thread</summary>
		internal void  threadEnding(CaselessString id)
		{
			lock (_threads.SyncRoot)
			{
				_threads.Remove(id);
				System.Threading.Monitor.PulseAll(_threads);
			}
		}
		
		
		/// <summary> Schedules a thread for immediate termination, and performs the appropriate
		/// interruptions. Does not wait for the thread to actually terminate.
		/// 
		/// </summary>
		/// <param name="threadid">the id of the thread to terminate
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException thread not found
		/// </exception>
		public void  terminateOneThread(CaselessString threadid)
		{
			lock (_threads.SyncRoot)
			{
				InterpreterThread thread = (InterpreterThread) (_threads[threadid]);
				if (thread == null)
				{
					throw new LanguageException("No such thread \"" + threadid + "\"");
				}
				thread.signalStop();
				thread.Interrupt();
			}
		}
		
		
		/// <summary> Schedules all threads for immediate termination, and performs the appropriate
		/// interruptions. Does not wait for the threads to actually terminate.
		/// </summary>
		public void  terminateAllThreads()
		{
			lock (_threads.SyncRoot)
			{
				System.Collections.IEnumerator elems = _threads.Values.GetEnumerator();
				//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
				while (elems.MoveNext())
				{
					//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
					InterpreterThread thread = (InterpreterThread) (elems.Current);
					thread.signalStop();
					thread.Interrupt();
				}
			}
		}
		
		
		/// <summary> Wait for all threads to terminate.</summary>
		public void  waitForAllTerminated()
		{
			lock (_threads.SyncRoot)
			{
				while (_threads.Count != 0)
				{
					try
					{
						System.Threading.Monitor.Wait(_threads);
					}
					catch (System.Threading.ThreadInterruptedException /*e*/) //Birb: removed "e" to avoid compiler warning
					{
					}
				}
			}
		}
		
		
		/// <summary> Suspend machine</summary>
		public void  suspend()
		{
			lock (_suspendedLock)
			{
				_suspended++;
			}
		}
		
		
		/// <summary> Unsuspend machine</summary>
		public void  unsuspend()
		{
			lock (_suspendedLock)
			{
				_suspended--;
				if (_suspended == 0)
				{
					System.Threading.Monitor.PulseAll(_suspendedLock);
				}
			}
		}
		
		
		/// <summary> Check for suspension. Called during the execution of a thread.</summary>
		internal void  checkSuspend()
		{
			lock (_suspendedLock)
			{
				if (_suspended > 0)
				{
					try
					{
						System.Threading.Monitor.Wait(_suspendedLock);
					}
                    catch (System.Threading.ThreadInterruptedException /*e*/) //Birb: removed "e" to avoid compiler warning
                    {
					}
				}
			}
		}
		
		
		/// <summary> Get the machine's random number generator
		/// 
		/// </summary>
		/// <returns> the generator
		/// </returns>
		public System.Random random()
		{
			return _random;
		}
		
		
		/// <summary> Reseed the machine's random number generator
		/// 
		/// </summary>
		/// <param name="seed">the seed value
		/// </param>
		public void  randomize(long seed)
		{
			//UPGRADE_TODO: The differences in the expected value  of parameters for method 'java.util.Random.setSeed'  may cause compilation errors.  'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1092_3"'
			_random = new System.Random((System.Int32) seed);
		}
		
		
		/// <summary> Sets user info, using a key String and a data Object. Your console or
		/// your custom primitives can use this mechanism to store data associated
		/// with this machine, which should be useful for communicating between
		/// PrimitiveGroups. For example, FilePrimitives ane ExtFilePrimitives use
		/// this mechanism to keep track of the current working directory. setData
		/// overwrites any existing data with this key.
		/// 
		/// </summary>
		/// <param name="dataID">key for the data
		/// </param>
		/// <data>  the data to store </data>
		public void  setData(System.String dataID, System.Object data)
		{
			lock (_data.SyncRoot)
			{
				_data[dataID] = data;
			}
		}
		
		
		/// <summary> Gets user info associated with the given key. Returns null if the key
		/// is not found.
		/// 
		/// </summary>
		/// <param name="dataID">key for the data
		/// 
		/// </param>
		/// <returns> the data, or null if key not found.
		/// </returns>
		public System.Object getData(System.String dataID)
		{
			lock (_data.SyncRoot)
			{
				return _data[dataID];
			}
		}
		
		
		/// <summary> Mutator for default inStream
		/// 
		/// </summary>
		/// <param name="isid">the new stream name.
		/// </param>
		/// <param name="is">the new stream.
		/// </param>
		public void  setInStream(CaselessString isid, IOBase is_Renamed)
		{
			_instreamID = isid;
			_instream = is_Renamed;
		}
		
		
		/// <summary> Mutator for default outStream
		/// 
		/// </summary>
		/// <param name="isid">the new stream name.
		/// </param>
		/// <param name="is">the new stream.
		/// </param>
		public void  setOutStream(CaselessString osid, IOBase os)
		{
			_outstreamID = osid;
			_outstream = os;
		}
		
		
		/// <summary> Is the given name reserved?
		/// 
		/// </summary>
		/// <param name="name">the string to look for
		/// 
		/// </param>
		/// <returns> true if the string is reserved
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isReserved'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public bool isReserved(CaselessString name)
		{
			lock (this)
			{
				int i;
				for (i = 0; i < _primitiveGroups.Count; i++)
				{
					if (((PrimitiveGroup) (_primitiveGroups[i])).isPrimitive(name))
					{
						return true;
					}
				}
				if (name.Equals(ParseSpecial.strTO))
				{
					return true;
				}
				if (name.Equals(ParseSpecial.strTOMACRO))
				{
					return true;
				}
				if (name.Equals(ParseSpecial.strEND))
				{
					return true;
				}
				return false;
			}
		}
		
		
		/// <summary> Define a procedure
		/// 
		/// </summary>
		/// <param name="proc">the procedure to define
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'defineProc'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  defineProc(Procedure proc)
		{
			lock (this)
			{
				_clock++;
				_procs.Remove(proc.Name);
				_procs[proc.Name] = proc;
			}
		}
		
		
		/// <summary> Get a procedure
		/// 
		/// </summary>
		/// <param name="name">name of the procedure to look for
		/// 
		/// </param>
		/// <returns> the procedure, or null if not found
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'resolveProc'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public Procedure resolveProc(CaselessString name)
		{
			lock (this)
			{
				return (Procedure) (_procs[name]);
			}
		}
		
		
		/// <summary> Erase procedure
		/// 
		/// </summary>
		/// <param name="name">name of the procedure to erase
		/// 
		/// </param>
		/// <returns> true iff procedure existed
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eraseProc'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public bool eraseProc(CaselessString name)
		{
			lock (this)
			{
				System.Object tempObject;
				tempObject = _procs[name];
				_procs.Remove(name);
				return (tempObject != null);
			}
		}
		
		
		/// <summary> Make a global symbol name
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// </param>
		/// <param name="obj">value of the variable
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'makeName'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  makeName(CaselessString name, LogoObject obj)
		{
			lock (this)
			{
				_syms.makeForced(name, obj);
			}
		}
		
		
		/// <summary> Get value of a variable.
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// 
		/// </param>
		/// <returns> the resolved symbol, or null if not found
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'resolveName'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoObject resolveName(CaselessString name)
		{
			lock (this)
			{
				return _syms.resolve(name);
			}
		}
		
		
		/// <summary> Erase a variable.
		/// 
		/// </summary>
		/// <param name="name">the name of the variable
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eraseName'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  eraseName(CaselessString name)
		{
			lock (this)
			{
				_syms.erase(name);
			}
		}
		
		
		/// <summary> Make a property
		/// 
		/// </summary>
		/// <param name="name">property list name
		/// </param>
		/// <param name="key">property key name
		/// </param>
		/// <param name="obj">value of the property
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException invalid access to system property
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'putProp'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  putProp(CaselessString name, CaselessString key, LogoObject obj)
		{
			lock (this)
			{
				if (name.Equals(LOGO_PROPERTYLIST_NAME))
				{
					if (key.Equals("LOGO.CASESENSITIVE"))
					{
						CaselessString.Sensitivity = obj.toBoolean();
					}
					else if (key.Equals("LOGO.OVERRIDEPRIMITIVES"))
					{
						_overridePrimitive = obj.toBoolean();
					}
					else if (key.Equals("LOGO.AUTOIGNORE"))
					{
						_autoIgnore = obj.toBoolean();
					}
					else
					{
						throw new LanguageException("Can't write to property " + key.ToString() + " in system property list.");
					}
				}
				else
				{
					System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[name]);
					if (list == null)
					{
						list = System.Collections.Hashtable.Synchronized(new System.Collections.Hashtable());
						_proplists[name] = list;
					}
					list.Remove(key);
					list[key] = obj;
				}
			}
		}
		
		
		/// <summary> Get value of a property
		/// 
		/// </summary>
		/// <param name="name">property list name
		/// </param>
		/// <param name="key">property key name
		/// 
		/// </param>
		/// <returns> value of the property
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException invalid access to system property
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getProp'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoObject getProp(CaselessString name, CaselessString key)
		{
			lock (this)
			{
				if (name.Equals(LOGO_PROPERTYLIST_NAME))
				{
					if (key.Equals("LOGO.CASESENSITIVE"))
					{
						return new LogoWord(CaselessString.Sensitivity);
					}
					else if (key.Equals("LOGO.OVERRIDEPRIMITIVES"))
					{
						return new LogoWord(_overridePrimitive);
					}
					else if (key.Equals("LOGO.AUTOIGNORE"))
					{
						return new LogoWord(_autoIgnore);
					}
					else if (key.Equals("LOGO.VERSION"))
					{
						return new LogoWord(TURTLETRACKS_VERSION);
					}
					else if (key.Equals("JAVA.VERSION"))
					{
						//UPGRADE_ISSUE: Method 'java.lang.System.getProperty' was not converted. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1000_javalangSystem_3"'
						return new LogoWord(".NET C#"); //System_Renamed.getProperty("java.version")); //Birb-JLCA: returning dummy java.version system property
					}
					else if (key.Equals("OS.NAME"))
					{
						//UPGRADE_TODO: Method 'java.lang.System.getProperty' was converted to 'System.Environment.GetEnvironmentVariable' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javalangSystemgetProperty_javalangString_3"'
						return new LogoWord(System.Environment.GetEnvironmentVariable("OS"));
					}
					else if (key.Equals("OS.ARCH"))
					{
						//UPGRADE_TODO: Method 'java.lang.System.getProperty' was converted to 'System.Environment.GetEnvironmentVariable' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javalangSystemgetProperty_javalangString_3"'
						return new LogoWord(System.Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE"));
					}
					else
					{
						throw new LanguageException("Can't read property " + key.ToString() + " in system property list.");
					}
				}
				else
				{
					System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[name]);
					if (list != null)
					{
						LogoObject ret = (LogoObject) (list[key]);
						if (ret != null)
						{
							return ret;
						}
					}
				}
				return new LogoList();
			}
		}
		
		
		/// <summary> Remove a property
		/// 
		/// </summary>
		/// <param name="name">property list name
		/// </param>
		/// <param name="key">property key name
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException invalid access to system property
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'remProp'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  remProp(CaselessString name, CaselessString key)
		{
			lock (this)
			{
				if (name.Equals(LOGO_PROPERTYLIST_NAME))
				{
					throw new LanguageException("Can't remove properties from system property list.");
				}
				else
				{
					System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[name]);
					if (list != null)
					{
						list.Remove(key);
						if ((list.Count == 0))
						{
							_proplists.Remove(name);
						}
					}
				}
			}
		}
		
		
		/// <summary> Get properties in given list
		/// 
		/// </summary>
		/// <param name="name">property list name
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getPropsInList'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public LogoList getPropsInList(CaselessString name)
		{
			lock (this)
			{
				System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[name]);
				if (list == null)
				{
					return new LogoList();
				}
				else
				{
					System.Collections.ArrayList v = System.Collections.ArrayList.Synchronized(new System.Collections.ArrayList(10));
					System.Collections.IEnumerator enum_Renamed = list.Keys.GetEnumerator();
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						v.Add(new LogoWord((CaselessString) (enum_Renamed.Current)));
					}
					
					return new LogoList(v);
				}
			}
		}
		
		
		/// <summary> Get props in proper format for Runtime.exec()
		/// 
		/// </summary>
		/// <param name="name">property list name
		/// </param>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'getPropsForExec'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public System.String[] getPropsForExec(CaselessString name)
		{
			lock (this)
			{
				System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[name]);
				if (list == null)
				{
					return null;
				}
				else
				{
					System.String[] ret = new System.String[list.Count];
					System.Collections.IEnumerator enum_Renamed = list.Keys.GetEnumerator();
					int i = 0;
					
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						CaselessString key = (CaselessString) (enum_Renamed.Current);
						LogoObject obj = (LogoObject) (list[key]);
						if (obj is LogoList)
						{
							ret[i] = key.str + '=' + ((LogoList) obj).toStringOpen();
						}
						else
						{
							ret[i] = key.str + '=' + ((LogoList) obj).ToString();
						}
						i++;
					}
					
					return ret;
				}
			}
		}
		
		
		/// <summary> Erase all procedures. names, and property lists</summary>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'eraseAll'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  eraseAll()
		{
			lock (this)
			{
				_syms.eraseAll();
				_procs.Clear();
				_proplists.Clear();
			}
		}
		
		
		/// <summary> Register a fileid
		/// 
		/// </summary>
		/// <param name="fileid">the fileid to register
		/// </param>
		/// <param name="io">the IOInterface to register
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException duplicate file id
		/// </exception>
		public void  registerIO(CaselessString fileid, IOBase io)
		{
			lock (_fileids.SyncRoot)
			{
				if (_fileids.ContainsKey(fileid))
				{
					throw new LanguageException("Duplicate fileid");
				}
				_fileids[fileid] = io;
			}
		}
		
		
		/// <summary> Get a stream given the id
		/// 
		/// </summary>
		/// <param name="fileid">fileid
		/// 
		/// </param>
		/// <returns> the IOInterface, or null if not found
		/// </returns>
		public IOBase getIO(CaselessString fileid)
		{
			lock (_fileids.SyncRoot)
			{
				return (IOBase) (_fileids[fileid]);
			}
		}
		
		
		/// <summary> Erase stream given the id
		/// 
		/// </summary>
		/// <param name="fileid">fileid
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException fileid is closed already
		/// </exception>
		public void  closeIO(CaselessString fileid)
		{
			lock (_fileids.SyncRoot)
			{
				System.Object tempObject;
				tempObject = _fileids[fileid];
				_fileids.Remove(fileid);
				IOBase io = (IOBase) (tempObject);
				if (io == null)
				{
					throw new LanguageException("Stream is closed");
				}
				else
				{
					io.close();
				}
			}
		}
		
		
		/// <summary> Close all streams</summary>
		public void  closeAllIO()
		{
			lock (_fileids.SyncRoot)
			{
				System.Collections.IEnumerator enum_Renamed = _fileids.Keys.GetEnumerator();
				
				try
				{
					//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
					while (enum_Renamed.MoveNext())
					{
						//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
						closeIO((CaselessString) (enum_Renamed.Current));
					}
				}
                catch (LanguageException /*e*/) //Birb: removed "e" to avoid compiler warning
                {
				}
			}
		}
		
		
		/// <summary> Read and execute stream. Closes the stream afterwards.
		/// 
		/// </summary>
		/// <param name="stream">the stream to load from
		/// </param>
		/// <param name="thread">thread running when LOAD instruction encountered
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException unable to execute
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'executeStream'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  executeStream(IOBase stream, InterpreterThread thread)
		{
			lock (this)
			{
				try
				{
					Tokenizer tokenizer = new Tokenizer(TokenizerCommentFlags); //Birb: J# (.net) with warning level set to 4 shows a false warning here
					thread.startLoading(stream);
					while (true)
					{
						if (stream.eof())
						{
							break;
						}
						System.Text.StringBuilder cumulative = new System.Text.StringBuilder();
						LogoList line = null;
						while (true)
						{
							if (stream.eof())
							{
								break;
							}
							try
							{
								cumulative.Append(thread.inStream().getLine());
								if (cumulative.Length > 0)
								{
									if (cumulative[cumulative.Length - 1] == '~')
									{
										cumulative[cumulative.Length - 1] = ' ';
									}
									else
									{
										line = tokenizer.tokenize(cumulative.ToString());
										break;
									}
								}
							}
							catch (LanguageException e)
							{
								char promptChar = e.ContChar;
								if (promptChar == '|' || promptChar == '\\' || promptChar == '~')
								{
									cumulative.Append(Machine.LINE_SEPARATOR);
								}
								else
								{
									throw e;
								}
							}
						}
						if (line != null)
						{
							line.getRunnable(thread.mach()).execute(new InterpEnviron(thread));
						}
					}
				}
				catch (LanguageException e)
				{
					throw new LanguageException("Error while running: " + e.generateMessage());
				}
				catch (ThrowException e)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					throw new LanguageException("Error while running: " + e.ToString());
				}
				finally
				{
					stream.close();
					thread.endLoading();
				}
			}
		}
		
		
		/// <summary> Printout specified info to stream
		/// 
		/// </summary>
		/// <param name="stream">the stream to print to
		/// </param>
		/// <param name="procs">the procedures to print
		/// </param>
		/// <param name="names">the names to print
		/// </param>
		/// <param name="plists">the property lists to print
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException unable to print
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'printout'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public void  printout(IOBase stream, LogoObject procs, LogoObject names, LogoObject plists)
		{
			lock (this)
			{
				System.Collections.IEnumerator enum_Renamed;
				
				if (names != null)
				{
					enum_Renamed = names.enumerateCaselessStrings();
				}
				else
				{
					enum_Renamed = _syms.EnumeratedNames;
				}
				//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
				while (enum_Renamed.MoveNext())
				{
					//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
					CaselessString sym = (CaselessString) (enum_Renamed.Current);
					LogoObject obj = _syms.resolve(sym);
					if (obj == null)
					{
						throw new LanguageException(sym + " has no value.");
					}
					System.String symStr = sym.unparse();
					System.String valStr = obj.unparse();
					if (obj is LogoList)
					{
						stream.putLine("MAKE \"" + symStr + ' ' + valStr);
					}
					else if (obj is LogoWord)
					{
						stream.putLine("MAKE \"" + symStr + " \"" + valStr);
					}
				}
				
				if (plists != null)
				{
					enum_Renamed = plists.enumerateCaselessStrings();
				}
				else
				{
					enum_Renamed = _proplists.Keys.GetEnumerator();
				}
				//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
				while (enum_Renamed.MoveNext())
				{
					//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
					CaselessString sym = (CaselessString) (enum_Renamed.Current);
					System.String symStr = sym.unparse();
					System.Collections.Hashtable list = (System.Collections.Hashtable) (_proplists[sym]);
					if (list != null)
					{
						System.Collections.IEnumerator enum2 = list.Keys.GetEnumerator();
						//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
						while (enum2.MoveNext())
						{
							//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
							CaselessString key = (CaselessString) (enum2.Current);
							LogoObject obj = (LogoObject) (list[key]);
							System.String keyStr = key.unparse();
							System.String valStr = obj.unparse();
							if (obj is LogoList)
							{
								stream.putLine("PPROP \"" + symStr + " \"" + keyStr + ' ' + valStr);
							}
							else if (obj is LogoWord)
							{
								stream.putLine("PPROP \"" + symStr + " \"" + keyStr + " \"" + valStr);
							}
						}
					}
				}
				
				if (procs != null)
				{
					enum_Renamed = procs.enumerateCaselessStrings();
				}
				else
				{
					enum_Renamed = _procs.Keys.GetEnumerator();
				}
				//UPGRADE_TODO: Method 'java.util.Enumeration.hasMoreElements' was converted to 'System.Collections.IEnumerator.MoveNext' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationhasMoreElements_3"'
				while (enum_Renamed.MoveNext())
				{
					//UPGRADE_TODO: Method 'java.util.Enumeration.nextElement' was converted to 'System.Collections.IEnumerator.Current' which has a different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1073_javautilEnumerationnextElement_3"'
					CaselessString sym = (CaselessString) (enum_Renamed.Current);
					Procedure proc = (Procedure) (_procs[sym]);
					if (proc == null)
					{
						throw new LanguageException("I don't know how to " + sym);
					}
					stream.putLine("");
					proc.writeToIO(stream);
				}
			}
		}
	}
}