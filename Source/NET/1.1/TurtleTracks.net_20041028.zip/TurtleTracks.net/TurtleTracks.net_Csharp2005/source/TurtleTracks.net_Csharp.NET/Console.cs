/*
===============================================================================

FILE:  Console.java

PROJECT:

Turtle Tracks

CONTENTS:

Interface to console objects

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Console interface. All console objects must extend this abstract class.</summary>
	
	public abstract class Console : IOBase, IThreadRunnable
	{
		/// <summary> Set machine. Should normally only be called once.
		/// 
		/// </summary>
		/// <param name="mach">the machine to use
		/// </param>
		virtual internal Machine Machine
		{
			set
			{
				_mach = value;
			}
			
		}
		
		private static LogoObject _kind;
		
		/// <summary> The machine associated with this console.</summary>
		protected internal Machine _mach;
		
		
		/// <summary> This method is called by the machine during setup. A console should override
		/// this method and perform any initialization here. If an error occurs,
		/// it should throw a SetupException.
		/// 
		/// </summary>
		/// <exception cref=""> turtletracks_net.jsharp.SetupException couldn't set up the console.
		/// </exception>
		protected internal virtual void  setup()
		{
		}
		
		
		/// <summary> Get machine associated with this console
		/// 
		/// </summary>
		/// <returns> the machine
		/// </returns>
		public Machine mach()
		{
			return _mach;
		}
		
		
		/// <summary> Close the stream. The default method throws a LanguageException.
		/// Consoles should normally not override this behavior.
		/// 
		/// </summary>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException can't close (console)
		/// </exception>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'close'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public virtual void  close()
		{
			lock (this)
			{
				throw new LanguageException("Can't close console");
			}
		}
		
		
		/// <summary> Is the stream open? The default method always returns true. Consoles
		/// should normally not override this behavior.
		/// 
		/// </summary>
		/// <returns> true iff can interact with stream
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'isOpen'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public virtual bool isOpen()
		{
			lock (this)
			{
				return true;
			}
		}
		
		
		/// <summary> Get the name of this object. The default method returns the empty
		/// LogoList, to indicate the console I/O object. Consoles should normally
		/// not override this behavior.
		/// 
		/// </summary>
		/// <returns> the name as a LogoObject
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'name'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public virtual LogoObject name()
		{
			lock (this)
			{
				return new LogoList();
			}
		}
		
		
		/// <summary> Get the kind of this object. The default method returns the word
		/// "CONSOLE". Consoles should normally not override this behavior.
		/// 
		/// </summary>
		/// <returns> the kind as a LogoObject
		/// </returns>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'kind'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public virtual LogoObject kind()
		{
			lock (this)
			{
				return _kind;
			}
		}
		
		
		/// <summary> Has the stream encountered EOF?
		/// 
		/// </summary>
		/// <returns> true iff eof encountered
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException stream closed
		/// </exception>
		public abstract bool eof();
		
		
		/// <summary> Get a line from the stream
		/// 
		/// </summary>
		/// <returns> the string
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException read not allowed, or io closed
		/// </exception>
		public abstract System.String getLine();
		
		
		/// <summary> Get all available data from stream
		/// 
		/// </summary>
		/// <param name="buf">buffer to read into
		/// 
		/// </param>
		/// <returns> how much data was actually read
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException read not allowed, or io closed
		/// </exception>
		public abstract int getAvailable(char[] buf);
		
		
		/// <summary> Get a character from the stream
		/// 
		/// </summary>
		/// <returns> char the character
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException read not allowed, or io closed
		/// </exception>
		public abstract char getChar();
		
		
		/// <summary> Character available on stream?
		/// 
		/// </summary>
		/// <returns> true iff available
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException read not allowed, or io closed
		/// </exception>
		public abstract bool charAvail();
		
		
		/// <summary> Prompt and read a command
		/// 
		/// </summary>
		/// <param name="prompt">the prompt
		/// </param>
		public abstract System.String promptGetLine(char prompt);
		
		
		/// <summary> Write a string to the stream
		/// 
		/// </summary>
		/// <param name="str">the string
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException write not allowed, or io closed
		/// </exception>
		public abstract void  put(System.String str);
		
		
		/// <summary> Write a char to the stream
		/// 
		/// </summary>
		/// <param name="c">the char
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException write not allowed, or io closed
		/// </exception>
		public abstract void  put(char c);
		
		
		/// <summary> Write a char array to the stream
		/// 
		/// </summary>
		/// <param name="buf">the buffer
		/// </param>
		/// <param name="num">number of characters
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException write not allowed, or io closed
		/// </exception>
		public abstract void  put(char[] buf, int num);
		
		
		/// <summary> Write a string to the stream, terminated with a newline
		/// 
		/// </summary>
		/// <param name="str">the string
		/// </param>
		public abstract void  putLine(System.String str);
		
		
		/// <summary> Write a string to the stream, terminated with a newline, as a console
		/// status message. Consoles can override this method to ignore the string if
		/// they want to suppress status messages. This method is used by the TO
		/// and TOMACRO special forms 
		/// 
		/// </summary>
		/// <param name="str">the string
		/// </param>
		public virtual void  putStatusMessage(System.String str)
		{
			putLine(str);
		}
		
		
		/// <summary> "Flush" the console.</summary>
		//UPGRADE_NOTE: Synchronized keyword was removed from method 'flush'. Lock expression was added. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1027_3"'
		public virtual void  flush()
		{
			lock (this)
			{
			}
		}
		
		
		/// <summary> Request a new editor
		/// 
		/// </summary>
		/// <param name="data">initial data for editor window
		/// 
		/// </param>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException Unable to create editor
		/// </exception>
		public abstract void  createEditor(System.String data);
		
		
		/// <summary> This method is called when the machine is closing down. A console should
		/// override this method to perform any cleanup, such as closing windows or files.
		/// </summary>
		protected internal virtual void  exiting()
		{
		}
		
		
		/// <summary> This method is called when a "goodbye" exception is thrown. A console should
		/// override it to perform any necessary processing. It is called in the thread
		/// that threw the exception, but other threads may still be running.
		/// </summary>
		public virtual void  goodbye()
		{
		}
		
		
		/// <summary> This method is called to actually run the interpreter. The exact behavior of
		/// this method should depend on the application. Interactive Logo consoles, for
		/// example, would include a loop of acquiring the next command and executing it,
		/// until the goodbye() method is called.
		/// </summary>
		public virtual void  Run()
		{
		}
		static Console()
		{
			{
				_kind = new LogoWord("CONSOLE");
			}
		}
	}
}