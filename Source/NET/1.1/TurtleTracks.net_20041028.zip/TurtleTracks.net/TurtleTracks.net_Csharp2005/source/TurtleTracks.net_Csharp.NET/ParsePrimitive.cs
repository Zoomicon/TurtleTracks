/*
===============================================================================

FILE:  ParsePrimitive.java

PROJECT:

Turtle Tracks

CONTENTS:

Primitive node in a parse tree

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> Primitive node in a parse tree</summary>
	
	public class ParsePrimitive:ParseObject, System.ICloneable
	{
		
		private PrimitiveSpec _spec;
		private System.String _name;
		private ParseObject[] _args;
		
		
		/// <summary> Construct the ParsePrimitive
		/// 
		/// </summary>
		/// <param name="spec">the primitive definition specification
		/// </param>
		/// <param name="name">the name of the primitive, given in the code
		/// </param>
		/// <param name="args">the arguments given to the primitive, as parse tree nodes
		/// </param>
		public ParsePrimitive(PrimitiveSpec spec, System.String name, ParseObject[] args)
		{
			_spec = spec;
			_name = name;
			_args = args;
		}
		
		
		/// <summary> Clone the object
		/// 
		/// </summary>
		/// <returns> a clone of this object
		/// </returns>
        public override System.Object Clone()/*:*/{ //Birb-JLCA, removed ":", added "override"
            return new ParsePrimitive(_spec, _name, _args);
		}
		/*{ //Birb-JLCA
		}*/ 
		
		
		/// <summary> Determine if another object is equal to this one
		/// 
		/// </summary>
		/// <param name="obj">what to compare with
		/// 
		/// </param>
		/// <returns> true iff equal
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			return false;
		}
		
		
		/// <summary> The name of the procedure
		/// 
		/// </summary>
		/// <returns> the name
		/// </returns>
		internal override System.String procName()
		{
			return _name;
		}
		
		
		/// <summary> Evaluate this object in the given environment
		/// 
		/// </summary>
		/// <param name="interp">the environment
		/// 
		/// </param>
		/// <returns> the return value
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.jsharp.ThrowException exception thrown
		/// </exception>
		internal override LogoObject evaluate(InterpEnviron interp)
		{
			// Evaluate arguments
			LogoObject[] evalArgs = new LogoObject[_args.Length];
			System.Object[] params_Renamed = new System.Object[2];
			for (int i = 0; i < _args.Length; i++)
			{
				evalArgs[i] = _args[i].evaluate(interp);
				if (evalArgs[i] == LogoVoid.obj)
				{
					throw new LanguageException(_args[i].procName().ToUpper() + " didn't output to " + _name.ToUpper());
				}
			}
			
			// Check for thread suspension and termination
			System.Threading.Thread.Sleep(0);
			interp.mach().checkSuspend();
			if (interp.thread().stopping())
			{
				throw new ThrowException(".SUDDENSTOPTHREAD");
			}
			
			// Invoke primitive
			params_Renamed[0] = interp;
			params_Renamed[1] = evalArgs;
			LogoObject ret = LogoVoid.obj;
			try
			{
				ret = (LogoObject) (_spec.method().Invoke(_spec.group(), (System.Object[]) params_Renamed));
			}
			catch (System.UnauthorizedAccessException e)
			{
				//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
				throw new LanguageException(e.ToString());
			}
			catch (System.Reflection.TargetInvocationException e)
			{
				//UPGRADE_NOTE: Exception 'java.lang.Throwable' was converted to 'System.Exception' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
				System.Exception ex = e.GetBaseException();
				if (ex is LanguageException)
				{
					LanguageException lex = (LanguageException) ex;
					if (lex.PrimName == null && lex.ProcName == null)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.getMessage' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						throw new LanguageException(lex.Message, _name, null, lex.ContChar);
					}
					else
					{
						throw lex;
					}
				}
				else if (ex is ThrowException)
				{
					throw (ThrowException) ex;
				}
				else if (ex is System.Security.SecurityException)
				{
					//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
					throw new LanguageException(ex.ToString(), _name, null);
				}
				else
				{
					//UPGRADE_NOTE: Exception 'java.lang.ThreadDeath' was converted to 'System.ApplicationException' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
					if (ex is System.ApplicationException)
					{
						//UPGRADE_NOTE: Exception 'java.lang.ThreadDeath' was converted to 'System.ApplicationException' which has different behavior. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1100_3"'
						throw (System.ApplicationException) ex;
					}
					else
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Throwable.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						throw new LanguageException(ex.ToString(), _name);
					}
				}
			}
			return ret;
		}
		//UPGRADE_NOTE: The following method implementation was automatically added to preserve functionality. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1306_3"'
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}
	}
}