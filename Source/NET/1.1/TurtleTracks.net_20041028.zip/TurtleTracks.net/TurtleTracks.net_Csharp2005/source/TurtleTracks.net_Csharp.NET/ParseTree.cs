/*
===============================================================================

FILE:  ParseTree.java

PROJECT:

Turtle Tracks

CONTENTS:

Runnable parse tree

PROGRAMMERS:

Daniel Azuma (DA)  <dazuma@kagi.com>

COPYRIGHT:

Copyright (C) 1997-1999  Daniel Azuma  (dazuma@kagi.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program. If not, you can obtain a copy
by writing to:
Free Software Foundation, Inc.
59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.

VERSION:

Turtle Tracks 1.0  (13 November 1999)

CHANGE HISTORY:

13 November 1999 -- DA -- Released under GNU General Public License

===============================================================================*/
using System;
namespace turtletracks_net.jsharp
{
	
	
	/// <summary> ParseTree object, ready to be interpreted.</summary>
	
	public sealed class ParseTree : System.ICloneable
	{
		
		private ParseObject[] _lis;
		private int _clock;
		
		
		/// <summary> Construct a tree given a clock value and a vector of parse objects.
		/// 
		/// </summary>
		/// <param name="clock">the clock value for the creation of the parse tree
		/// </param>
		/// <param name="v">the vector of ParseObjects
		/// </param>
		public ParseTree(int clock, System.Collections.ArrayList v)
		{
			int i;
			_lis = new ParseObject[v.Count];
			for (i = 0; i < _lis.Length; i++)
			{
				_lis[i] = (ParseObject) (v[i]);
			}
			_clock = clock;
		}
		
		
		/// <summary> Construct a tree given a clock value and an array of parse objects.
		/// 
		/// </summary>
		/// <param name="clock">the clock value for the creation of the parse tree
		/// </param>
		/// <param name="a">the array of ParseObjects
		/// </param>
		public ParseTree(int clock, ParseObject[] a)
		{
			_clock = clock;
			_lis = a;
		}
		
		
		/// <summary> Test the clock value
		/// 
		/// </summary>
		/// <returns> true iff the tree is current, i.e. _clock is -1 (unexpirable) or
		/// _clock equals the remoteclock from the machine.
		/// </returns>
		internal bool testClock(int remoteClock)
		{
			return _clock == - 1 || remoteClock == _clock;
		}
		
		
		/// <summary> Clone the object
		/// 
		/// </summary>
		/// <returns> a clone of this object
		/// </returns>
        public System.Object Clone()/*:*/{ //Birb-JLCA, removed ":"
            ParseObject[] a = new ParseObject[_lis.Length];
			int i;
			for (i = 0; i < _lis.Length; i++)
			{
				a[i] = (ParseObject) (_lis[i].Clone());
			}
			return new ParseTree(_clock, a);
		}
		/*{ //Birb-JLCA
		}*/
		
		
		/// <summary> Determine if another object is equal to this one
		/// 
		/// </summary>
		/// <param name="obj">what to compare with
		/// 
		/// </param>
		/// <returns> true iff equal
		/// </returns>
		public  override bool Equals(System.Object obj)
		{
			return false;
		}
		
		
		/// <summary> Returns length of the parse tree
		/// 
		/// </summary>
		/// <returns> the length
		/// </returns>
		public int length()
		{
			return _lis.Length;
		}
		
		
		/// <summary> Executes this parse tree
		/// 
		/// </summary>
		/// <param name="interp">the interpreter environment
		/// 
		/// </param>
		/// <returns> the result
		/// 
		/// </returns>
		/// <exception cref=""> turtletracks_net.jsharp.LanguageException error thrown
		/// </exception>
		/// <exception cref=""> turtletracks_net.jsharp.ThrowException exception thrown
		/// </exception>
		public LogoObject execute(InterpEnviron interp)
		{
			LogoObject ret = LogoVoid.obj;
			int i;
			
			for (i = 0; i < _lis.Length; i++)
			{
				LogoObject ret2 = _lis[i].evaluate(interp);
				if (ret2 != LogoVoid.obj)
				{
					if (!interp.mach().AutoIgnore && ret != LogoVoid.obj)
					{
						//UPGRADE_TODO: The equivalent in .NET for method 'java.lang.Object.toString' may return a different value. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1043_3"'
						throw new LanguageException("You don't say what to do with " + ret);
					}
					else
					{
						ret = ret2;
					}
				}
			}
			
			return ret;
		}
		//UPGRADE_NOTE: The following method implementation was automatically added to preserve functionality. 'ms-help://MS.VSCC.v80/dv_commoner/redir/redirect.htm?keyword="jlca1306_3"'
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}
	}
}