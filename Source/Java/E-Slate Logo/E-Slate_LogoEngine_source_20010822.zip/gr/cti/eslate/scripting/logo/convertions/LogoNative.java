//Version: 8Aug2001

package gr.cti.eslate.scripting.logo.convertions;

import virtuoso.logo.*;
import java.awt.*;

public class LogoNative {

 /**
  * @since: 8Aug2001
  */
 public static final Object convertLogoObject(LogoObject value, Class type)
  throws LanguageException
 {
  String typename=type.getName();

  //more frequent native types//
  if(type==java.lang.String.class) return value.toString();
  if(typename.equals("int") || type==java.lang.Integer.class) return new Integer(value.toInteger());
  if(typename.equals("boolean") || type==java.lang.Boolean.class) return new Boolean(value.toBoolean());
  if(typename.equals("double") || type==java.lang.Double.class) return new Double(value.toNumber());

  //less frequent native types//
  if(typename.equals("long") || type==java.lang.Long.class) return new Long(value.toInteger());
  if(typename.equals("float") || type==java.lang.Float.class) return new Float(value.toNumber()); //might loose in accuracy?
  if(typename.equals("char") || type==java.lang.Character.class) return new Character(value.toString().charAt(0)); //return first char of string
  if(typename.equals("byte") || type==java.lang.Byte.class) return new Byte((byte)value.toInteger()); //cut down to a byte

  return null;
 }

 ////////

 public static final LogoObject toLogoObject(String[] strings){ //31May2000
  int count=strings.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(strings[i]);
  return new LogoList(items);
 }

 /////////

 public static final LogoObject toLogoObject(int[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 public static final LogoObject toLogoObject(float[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 public static final LogoObject toLogoWord(double[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 public static final LogoObject toLogoObject(short[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 public static final LogoObject toLogoObject(long[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 public static final LogoObject toLogoObject(byte[] numbers){ //31May2000
  int count=numbers.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(numbers[i]);
  return new LogoList(items);
 }

 /////////

 public static final LogoObject toLogoWord(boolean[] booleans){
  int count=booleans.length;
  LogoObject items[] = new LogoObject[count];
  for(int i=count;i-->0;) items[i]=new LogoWord(booleans[i]);
  return new LogoList(items);
 }

}
