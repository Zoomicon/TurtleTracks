package gr.cti.eslate.sharedObject;

import gr.cti.eslate.base.*;
import gr.cti.eslate.base.sharedObject.*;
import gr.cti.eslate.logo.ProcedureCall;
import java.applet.*;

public class LogoCallSO extends SharedObject
{
 ProcedureCall call=null;
 public Integer executeAtForcedClock=null;

 public static final int NEW_CALL=1;

 public LogoCallSO(ESlateHandle app){ //18May1999: ESlateII
  super(app);
 }

 //

 public synchronized void set_call(ProcedureCall call){ //Synchronized!!!
  this.call=call;
  synchronized(this){ //12-7-98: !!!
   if (executeAtForcedClock!=null){
    int clock=executeAtForcedClock.intValue(); //get the clock value before setting executeAtForcedClock to null
    executeAtForcedClock=null; //unlock clock here (don't do in LOGO, cause exec was in a thread)   
    if (call!=null) this.call.time=clock; //use explicit clock value if execution is forced at that time
    //check call for null: was firing exception when Logo-Slider double connection
    //System.out.println("LogoCallSO: executing at forced clock="+clock);
   }
  }
  fireSharedObjectChanged(new SharedObjectEvent(this,NEW_CALL)); //18May1999: ESlateII //22May1999: using new SO constructor
 }

 //

 public ProcedureCall get_call() {return this.call;}

}