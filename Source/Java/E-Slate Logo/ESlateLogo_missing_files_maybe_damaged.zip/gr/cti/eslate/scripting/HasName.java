package gr.cti.eslate.scripting;

public interface HasName{

 public String getName();
 public void setName(String value);

}
