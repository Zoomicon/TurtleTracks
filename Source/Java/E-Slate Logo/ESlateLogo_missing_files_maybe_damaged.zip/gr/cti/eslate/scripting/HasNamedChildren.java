package gr.cti.eslate.scripting;

public interface HasNamedChildren{

 public Object getChild(String name);
 public void addChild(String name,Object o);

}
