//27-7-1998//

package gr.cti.eslate.scripting;

import virtuoso.logo.*;

public interface LogoScriptable{
 public String[] getSupportedPrimitiveGroups();
}
